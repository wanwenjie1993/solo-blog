title: Tomcat启用GZIP压缩，提升web性能
date: '2019-04-11 15:04:03'
updated: '2019-04-11 15:04:03'
tags: [tomcat]
permalink: /articles/2019/04/11/1554966243567.html
---
server.xml，修订节点如下
```
<Connector port="8080"
protocol="HTTP/1.1"
connectionTimeout="20000"
redirectPort="8443"    
compression="on" 
compressionMinSize="1024" 
noCompressionUserAgents="gozilla, traviata"   
compressableMimeType="text/html,text/xml,text/javascript,
application/javascript,text/css,text/plain,text/json,application/json"/>
```
参数说明：

* compression="on" 开启压缩。可选值："on"开启，"off"关闭，"force"任何情况都开启。

* compressionMinSize="2048"大于2KB的文件才进行压缩。用于指定压缩的最小数据大小，单位B，默认2048B。注意此值的大小，如果配置不合理，产生的后果是小文件压缩后反而变大了，达不到预想的效果。

* noCompressionUserAgents="gozilla, traviata"，对于这两种浏览器，不进行压缩（我也不知道这两种浏览器是啥，百度上没找到），其值为正则表达式，匹配的UA将不会被压缩，默认空。

* compressableMimeType="text/html,text/xml,application/javascript,text/css,text/plain,text/json"会被压缩的MIME类型列表，多个逗号隔，表明支持html、xml、js、css、json等文件格式的压缩（plain为无格式的，但对于具体是什么，我比较概念模糊）。compressableMimeType很重要，它用来告知tomcat要对哪一种文件进行压缩，如果类型指定错误了，肯定是无法压缩的。那么，如何知道要压缩的文件类型呢？可以通过以下这种方法找到。



修改完之后重启下tomcat即可，最后去检测网站：[http://seo.chinaz.com/](http://seo.chinaz.com/?host=iitshare.com "检查网站") 查询下效果