title: 'ORA-01033: ORACLE initialization or shutdown in progress'
date: '2019-04-01 09:54:39'
updated: '2019-04-01 09:56:51'
tags: [oracle]
permalink: /articles/2019/04/01/1554083679006.html
---
* 连接数据库报错
`ORA-01033: ORACLE initialization or shutdown in progress;`
* `startup force;`强制重启后继续报错
ORA-16038: log 1 sequence# 697 cannot be archived
ORA-19809: limit exceeded for recovery files
ORA-00312: online log 1 thread 1: '/u01/app/oracle/oradata/orcl/redo01.log'

**处理方法**
```
sqlplus /nolog
```
```
conn / as sysdba;
```

```
select group#,sequence# from v$log;
```

    GROUP   SEQUENCE 
         1        697
         3        699
         2        698

```
alter database clear unarchived logfile group 1;
```
Database altered.

```
alter database open;
```
Database altered.

```
show parameter archive
```
NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
archive_lag_target                   integer     0
log_archive_config                   string
log_archive_dest                     string
log_archive_dest_1                   string
log_archive_dest_10                  string
log_archive_dest_2                   string
log_archive_dest_3                   string
log_archive_dest_4                   string
log_archive_dest_5                   string
log_archive_dest_6                   string
log_archive_dest_7                   string

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
log_archive_dest_8                   string
log_archive_dest_9                   string
log_archive_dest_state_1             string      enable
log_archive_dest_state_10            string      enable
log_archive_dest_state_2             string      enable
log_archive_dest_state_3             string      enable
log_archive_dest_state_4             string      enable
log_archive_dest_state_5             string      enable
log_archive_dest_state_6             string      enable
log_archive_dest_state_7             string      enable
log_archive_dest_state_8             string      enable

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
log_archive_dest_state_9             string      enable
log_archive_duplex_dest              string
log_archive_format                   string      %t_%s_%r.dbf
log_archive_local_first              boolean     TRUE
log_archive_max_processes            integer     2
log_archive_min_succeed_dest         integer     1
log_archive_start                    boolean     FALSE
log_archive_trace                    integer     0
remote_archive_enable                string      true
standby_archive_dest                 string      ?/dbs/arch
```