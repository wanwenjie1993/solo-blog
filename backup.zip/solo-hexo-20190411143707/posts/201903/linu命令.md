title: linu命令
date: '2019-03-28 16:37:21'
updated: '2019-03-28 16:37:21'
tags: [linux]
permalink: /articles/2019/03/28/1553762241292.html
---
查看端口号
sudo netstat -ntlp