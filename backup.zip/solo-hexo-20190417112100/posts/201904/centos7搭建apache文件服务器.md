title: centos7 搭建apache文件服务器
date: '2019-04-16 15:42:07'
updated: '2019-04-16 15:42:07'
tags: [apache]
permalink: /articles/2019/04/16/1555400527748.html
---
* 安装apache服务器
```
yum install httpd
```
报错：No package httpd available.
```
#更新仓库
yum -y update
```

2：启动httpd服务

service httpd start

3：查看httpd服务器的版本



4：修改访问端口和文件路径，以防端口冲突（修改apache的配置文件，默认路径是/etc/httpd/conf/httpd.conf）

如果想修改相应的端口，则修改Listen 80 为相应的端口号Listen 8000

httpd服务器默认访问的主目录   <Directory "/var/www/html"></Directory>

5：重启httpd服务

service httpd restart

6：登录网页查看



7：去掉apache的欢迎页面，为下载目录的结构

把/etc/httpd/conf.d/welcome.conf删除或者备份成/etc/httpd/conf.d/welcome.conf.bak（我个人习惯备份）

8：重新执行第五步重启httpd服务

9：登录网页查看
