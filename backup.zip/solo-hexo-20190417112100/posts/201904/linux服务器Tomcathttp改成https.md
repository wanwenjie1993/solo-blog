title: linux 服务器 Tomcat http 改成https
date: '2019-04-16 14:50:12'
updated: '2019-04-16 15:05:26'
tags: [tomcat]
permalink: /articles/2019/04/16/1555397411871.html
---
* **进入到tomcat config目录下**
```
cd /www/server/tomcat/conf
```
* **生成证书**
```
[root@VM_0_10_centos tomcat]# keytool -genkey -alias tomcat -keyalg RSA -keystore /www/server/tomcat/conf.keystore

Enter keystore password:  
Re-enter new password: 
What is your first and last name?
  [Unknown]:  Tomcat
What is the name of your organizational unit?
  [Unknown]:  Apache
What is the name of your organization?
  [Unknown]:  Apache
What is the name of your City or Locality?
  [Unknown]:  Beijing    
What is the name of your State or Province?
  [Unknown]:  Beijing
What is the two-letter country code for this unit?
  [Unknown]:  CN
Is CN=Tomcat, OU=Apache, O=Apache, L=Beijing, ST=Beijing, C=CN correct?
  [no]:  y

Enter key password for <tomcat>
        (RETURN if same as keystore password):  
Re-enter new password: 
They don't match. Try again
Enter key password for <tomcat>
        (RETURN if same as keystore password):  

Warning:
```
keytool -genkey：自动使用默认的算法生成公钥和私钥

-alias[名称]：给证书取个别名

-keyalg：制定密钥的算法，如果需要制定密钥的长度，可以再加上keysize参数，密钥长度默认为1024位，使用DSA算法时，密钥长度必须在512到1024之间，并且是64的整数倍

-keystore：参数可以指定密钥库的名称。密钥库其实是存放迷药和证书文件，密钥库对应的文件如果不存在会自动创建。

-validity：证书的有效日期，默认是90天

-keypass changeit：不添加证书密码

-storepass changeit：不添加存储证书的密码
* **修改配置tomcat服务器 server.xml**
```
 <Connector port="80" protocol="HTTP/1.1"
               connectionTimeout="20000"
               redirectPort="8443" 
               uRIEncoding="UTF-8"
               />
```

将8443 改成443 ，因为https默认的端口是443，http默认的80

释放以下，将8443改成443，保持对称 keystoreFile 和 keystorePass 添加上

```
<Connector port="443" protocol="org.apache.coyote.http11.Http11Protocol"
               maxThreads="150" SSLEnabled="true" scheme="https" secure="true"
               clientAuth="false" sslProtocol="TLS" 
  keystoreFile="/www/server/tomcat/conf.keystore" keystorePass="wanwenjie"
  /> 
```

4.重启tomcat

只运行 https,不允许http 则 web.xml 的 welcome-file-list 下面 中添加

```
<welcome-file-list>
        <welcome-file>/</welcome-file>
    </welcome-file-list>
<security-constraint>
        <web-resource-collection>
            <web-resource-name>sslwebsokect</web-resource-name>
            <url-pattern>/*</url-pattern>
        </web-resource-collection>
        <user-data-constraint>
            <transport-guarantee>CONFIDENTIAL</transport-guarantee>
        </user-data-constraint>
    </security-constraint>
```

6.再次重启tomcat，访问http后会自动跳转到https

5.浏览器访问https
