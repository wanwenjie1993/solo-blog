title: '生成awr报告时报ORA-06502: PL/SQL: 数字或值错误 : 字符串缓冲区太小'
date: '2019-03-25 16:36:15'
updated: '2019-03-25 16:36:15'
tags: [oracle]
permalink: /articles/2019/03/25/1553502975079.html
---
原文地址：https://blog.csdn.net/qyq88888/article/details/52024360

生成awr报告时报错：  
ERROR:  
ORA-06502: PL/SQL: 数字或值错误 :  字符串缓冲区太小  
ORA-06512: 在 "SYS.DBMS_WORKLOAD_REPOSITORY", line 919  
ORA-06512: 在 line 1

  
 

解决方法：

update WRH$_SQLTEXT set sql_text = SUBSTR(sql_text, 1, 1000);  
commit;

  

然后重新执行@?/rdmbs/admin/awrrpt.sql脚本顺利生成awr报告.