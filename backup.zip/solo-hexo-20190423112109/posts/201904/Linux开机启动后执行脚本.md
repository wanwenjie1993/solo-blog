title: Linux 开机启动后执行脚本
date: '2019-04-22 13:32:44'
updated: '2019-04-22 13:40:29'
tags: [linux]
permalink: /articles/2019/04/22/1555911163939.html
---
## 启动startFrpc为例子
* 在/etc/rc.d/init.d 目录下新建启动脚本 startFrpc
```
cd /etc/rc.d/init.d
vi startFrpc
```
保存以下内容
```
#!/bin/sh  
nohup /home/frp/frpc -c /home/frp/frpc.ini > /dev/null 2>&1 &
```
修改文件权限
```
chmod 755 startFrpc
```
* 在对应的目录下建立软连接(假设系统默认进入 X11)  
```
cd /etc/rc.d/rc5.d
```  
```
ln -s ../init.d/startFrpc S99startFrpc
```
* 重启系统即可