title: MSI排名预测
date: '2019-04-29 15:25:43'
updated: '2019-04-29 16:09:03'
tags: [LOL]
permalink: /articles/2019/04/29/1556522743473.html
---
选手排名：

Top: TheShy > Khan > Wunder > Zeros > Impact >= Hanabi

Jungle: Clid = Ning > Jankos > Xmithie >= Meliodas > Bugi

Mid: Faker = Rookie >= Caps > Jensen > Rather = Naul

ADC: Teddy > JackeyLove = Doublelift >= Perkz > BigKoro = Betty

Support: Mata = Baolan > CoreJJ > Mikyx = Palette > ShiaoC

战队排名：

1/2 - SKT/IG

3 - G2

4/5 - TL/PVB 

6 - FW