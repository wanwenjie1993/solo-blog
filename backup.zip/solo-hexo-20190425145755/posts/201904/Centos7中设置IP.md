title: Centos7中设置IP
date: '2019-04-10 13:26:17'
updated: '2019-04-10 13:41:48'
tags: [linux]
permalink: /articles/2019/04/10/1554873977434.html
---
* IP addr
查看IP和网卡 ip addr
![](https://ws3.sinaimg.cn/large/ab71ac88ly1g1xhg0iah5j20mh059gmd.jpg)
我这里网卡是  ens33 
* cd /etc/sysconfig/network-scripts/
 修改网卡 vi ifcfg-ens33 
![](https://ws2.sinaimg.cn/large/ab71ac88ly1g1xhea3levj20cd0740sy.jpg)
* reboot 重启