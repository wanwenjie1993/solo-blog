title: 'oracle问题记录 ORA-01033: ORACLE initialization or shutdown in progress'
date: '2019-04-10 11:02:54'
updated: '2019-04-15 09:36:56'
tags: [oracle]
permalink: /articles/2019/04/10/1554865374383.html
---
登录数据库报错
**ORA-01033: ORACLE initialization or shutdown in progress**
```
[oracle@localhost ~]$ sqlplus

SQL*Plus: Release 10.2.0.4.0 - Production on 星期一 4月 15 08:55:11 2019

Copyright (c) 1982, 2007, Oracle.  All Rights Reserved.

Enter user-name: csc
Enter password: 
ERROR:
ORA-01033: ORACLE initialization or shutdown in progress

[oracle@localhost ~]$ sqlplus /nolog


SQL*Plus: Release 10.2.0.4.0 - Production on 星期一 4月 15 08:56:55 2019

Copyright (c) 1982, 2007, Oracle.  All Rights Reserved.

SQL> conn / as sysdba;
Connected.
SQL> shutdown immediate;
ORA-01109: database not open


Database dismounted.
ORACLE instance shut down.
SQL> select group#,sequence# from v$log;
select group#,sequence# from v$log
*
ERROR at line 1:
ORA-01034: ORACLE not available


SQL> startup;
ORACLE instance started.

Total System Global Area 1224736768 bytes
Fixed Size                  2083560 bytes
Variable Size             754976024 bytes
Database Buffers          452984832 bytes
Redo Buffers               14692352 bytes
Database mounted.
ORA-16014: log 2 sequence# 401 not archived, no available destinations
ORA-00312: online log 2 thread 1: '/u01/app/oracle/oradata/orcl/redo02.log'


SQL> select group#,sequence# from v$log;

    GROUP#  SEQUENCE#
---------- ----------
         1        403
         3        404
         2        401

SQL> alter database clear unarchived logfile group 2;

Database altered.
#看出log2有问题
SQL> select group#,sequence# from v$log;

    GROUP#  SEQUENCE#
---------- ----------
         1        403
         3        404
         2          0

SQL> alter database open;

Database altered.

SQL> shutdown immediate;
Database closed.
Database dismounted.
ORACLE instance shut down.
SQL> startup
ORACLE instance started.

Total System Global Area 1224736768 bytes
Fixed Size                  2083560 bytes
Variable Size             754976024 bytes
Database Buffers          452984832 bytes
Redo Buffers               14692352 bytes
Database mounted.
Database opened.
SQL> sqlplus
SP2-0042: unknown command "sqlplus" - rest of line ignored.
SQL> quit       
Disconnected from Oracle Database 10g Enterprise Edition Release 10.2.0.4.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options
[oracle@localhost ~]$ sqlplus

SQL*Plus: Release 10.2.0.4.0 - Production on 星期一 4月 15 09:07:59 2019

Copyright (c) 1982, 2007, Oracle.  All Rights Reserved.

Enter user-name: csc
Enter password: 

Connected to:
Oracle Database 10g Enterprise Edition Release 10.2.0.4.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options

SQL> 
```