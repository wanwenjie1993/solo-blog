title: idea 使用
date: '2019-04-03 22:27:45'
updated: '2019-04-03 22:52:03'
tags: [idea]
permalink: /articles/2019/04/03/1554301665559.html
---
* Alt+Insert 选择需要重写的方法