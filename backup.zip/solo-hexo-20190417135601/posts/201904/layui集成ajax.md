title: layui集成ajax
date: '2019-04-01 22:20:20'
updated: '2019-04-01 22:20:20'
tags: [javascript]
permalink: /articles/2019/04/01/1554128420071.html
---
* 配置 /js/global.js
```
layui.config({

    base: '/static/modules/'      //自定义layui组件的目录
}).extend({ //设定组件别名
    common:   'common',
});
```
* 配置 /modules/common.js
```
layui.define(['jquery'], function(exports){ 

    var $ = layui.jquery;
    var obj = {
        ajax: function (url, type, dataType, data, callback) {
            $.ajax({
                url: url,
                type: type,
                dataType: dataType,
                data: data,
                success: callback
            });
        }
    };
    //输出接口
    exports('common', obj);
});
``````
function query(){
	layui.use(['common','layer'], function () {
		        var common = layui.common;
		                var layer = layui.layer;
		                var index = layer.load(2);
		        common.ajax('/dealerQuery', 'post', 'json', {
		            'dealer_code': $("#dealer_code").val(),
		        }, function (res) {
			if(res.length==0){
				  layer.msg("未找到数据");
				  layer.close(index);
                    return;
			}
				  layer.close(index);
		        });
		    });
		}
```