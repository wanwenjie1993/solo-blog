title: spring-boot-configuration-processor的作用
date: '2019-03-31 22:17:00'
updated: '2019-03-31 22:17:00'
tags: [sping]
permalink: /articles/2019/03/31/1554041820739.html
---
spring默认使用yml中的配置，但有时候要用传统的xml或properties配置，就需要使用spring-boot-configuration-processor了

先引入pom依赖

```
1         <dependency>
2             <groupId>org.springframework.boot</groupId>
3             <artifactId>spring-boot-configuration-processor</artifactId>
4             <optional>true</optional>
5         </dependency>
```

再在你的配置类开头加上@PropertySource("classpath:your.properties")，其余用法与加载yml的配置一样