title: 【SpringBoot】— lombok的使用和原理
date: '2019-03-31 22:17:54'
updated: '2019-03-31 22:17:54'
tags: [SpringBoot]
permalink: /articles/2019/03/31/1554041874916.html
---
前言：lombok是一个编译级别的插件，它可以在项目编译的时候生成一些代码。比如日常开发过程中需要生产大量的JavaBean文件，每个JavaBean都需要提供大量的getter()和setter方法，如果字段较多且发生变动的话修改起来相对繁琐，相应的lombok可以通过注解(@getter,@setter)为我们省去手动创建getter和setter方法的麻烦，它能够在我们编译源码的时候自动帮我们生成getter和setter方法。即它最终能够达到的效果是：在源码中没有getter和setter方法，但是在编译生成的字节码文件中有getter和setter方法。


另外在项目开发阶段，一个class的属性是一直变化的，今天可能增加一个字段，明天可能删除一个字段。每次变化都需要修改对应的模板代码。另外，有的class的字段超级多，多到一眼看不完。如果加上模板代码，更难一眼看出来。更有甚者，由于字段太多，想要使用builder来创建。手动创建builder和字段和原来的类夹杂在一起，看起来很凌乱。lombok的@Builder即可解决这个问题。

准备：

    maven依赖：

                <dependency>
			<groupId>org.projectlombok</groupId>
			<artifactId>lombok</artifactId>
			<version>1.16.6</version>
			<scope>provided</scope>
		</dependency>
