title: Shiro和Spring Security对比
date: '2019-03-31 22:47:35'
updated: '2019-03-31 22:47:35'
tags: [SpringBoot]
permalink: /articles/2019/03/31/1554043655320.html
---
**Shiro和Spring Security比较**
1.  Shiro比Spring更容易使用，实现和最重要的理解
2. Spring Security更加知名的唯一原因是因为品牌名称
3.   “Spring”以简单而闻名，但讽刺的是很多人发现安装Spring Security很难然而，Spring Security却有更好的社区支持
4. Apache Shiro在Spring Security处理密码学方面有一个额外的模块
5. Spring-security 对spring 结合较好，如果项目用的springmvc ，使用起来很方便。但是如果项目中没有用到spring，那就不要考虑它了。
6. Shiro 功能强大、且 简单、灵活。是Apache 下的项目比较可靠，且不跟任何的框架或者容器绑定，可以独立运行
