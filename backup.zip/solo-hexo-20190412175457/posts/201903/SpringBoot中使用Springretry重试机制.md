title: SpringBoot 中使用Spring retry 重试机制
date: '2019-03-31 22:26:42'
updated: '2019-03-31 22:26:42'
tags: [SpringBoot]
permalink: /articles/2019/03/31/1554042402379.html
---
在日常开发中重试机制还是比较常用的，比如因网络原因等引起的超时，必要的重试市必须的。  
那么在springboot中如何使用retry机制呢  
在启动类中增加@EnableRetry 表示开启重试

```
package com.kotlin.work

import org.springframework.boot.autoconfigure.EnableAutoConfiguration
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication
import org.springframework.context.annotation.ImportResource
import org.springframework.retry.annotation.EnableRetry

@SpringBootApplication
@EnableAutoConfiguration
@ImportResource(locations = ["classpath*:work-spring.xml"])
@EnableRetry
class WorkApplication

fun main(args: Array<String>) {
    runApplication<WorkApplication>(*args)
} 
```

重试service

```
package com.kotlin.work.service.service

import org.springframework.stereotype.Service
import org.springframework.remoting.RemoteAccessException
import org.springframework.retry.annotation.Backoff
import org.springframework.retry.annotation.Retryable
import org.springframework.retry.annotation.Recover

@Service
class RetryService {

    @Retryable(value = [RemoteAccessException::class], maxAttempts = 5, backoff = Backoff(delay = 5000L,multiplier = 0.0))
    @Throws(Exception::class)
    fun retryTest() {
        println("start retry...")
        throw RemoteAccessException("RemoteAccessException....")
    }

    @Recover
    fun recover(e: RemoteAccessException) {
        println(e.message)
        println("recover....")
    }


} 
```

调用参数

```
package com.kotlin.work.controller

import com.kotlin.work.service.service.RetryService
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RequestMethod
import org.springframework.web.bind.annotation.RestController
import javax.annotation.Resource

@RestController
@RequestMapping(value = "/hello")
class HelloController {


    @Resource
    val retryService :RetryService? = null

    @RequestMapping(value = "/create",method = [RequestMethod.POST,RequestMethod.GET])
    fun create():String{

        retryService!!.retryTest()
        return "hello"
    }

} 
```

注解说明  
@Retryable：标注此注解的方法在发生异常时会进行重试  
参数说明：value：抛出指定异常才会重试  
include：和value一样，默认为空，当exclude也为空时，默认所以异常  
exclude：指定不处理的异常  
maxAttempts:最大重试次数，默认3次  
backoff：重试等待策略，默认使用@Backoff，@Backoff的value默认为1000L，multiplier（指定延迟倍数）  
默认为0，表示固定暂停1秒后进行重试，如果把multiplier设置为2，则第一次重试为1秒，第二次为  
2秒，第三次为4秒  
@Recover：用于@Retryable重试失败后处理方法，此方法里的异常一定要是@Retryable方法里抛出的异常，否则不会调用  
这个方法