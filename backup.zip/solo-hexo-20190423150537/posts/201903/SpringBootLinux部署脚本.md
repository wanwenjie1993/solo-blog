title: SpringBoot Linux 部署脚本
date: '2019-03-24 23:13:43'
updated: '2019-03-24 23:15:54'
tags: [SpringBoot, linux, java]
permalink: /articles/2019/03/24/1553440423522.html
---
### 启动脚本 startup.sh
<table cellspacing="0" cellpadding="0" style="overflow-wrap: break-word; empty-cells: show; border-collapse: collapse; table-layout: fixed; width: 1661px; color: rgb(68, 68, 68); font-family: &quot;Segoe UI&quot;, Tahoma, &quot;Hiragino Sans GB&quot;, &quot;Microsoft Yahei&quot;, Simsun; font-size: 13px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-align: start; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(255, 255, 255); text-decoration-style: initial; text-decoration-color: initial;"><tbody style="overflow-wrap: break-word;"><tr style="overflow-wrap: break-word;"><td class="t_f" id="postmessage_24129472" style="overflow-wrap: break-word; font-size: 14px;"><div class="parsedown-markdown" style="overflow-wrap: break-word;"><p style="overflow-wrap: break-word; margin: 15px 0px; padding: 0px;"><h3 id="24129472_启动脚本-startup.sh" style="overflow-wrap: break-word; margin: 20px 0px; padding: 0px; font-size: 18px; font-weight: bold; border-bottom: 2px solid rgb(204, 204, 204);">启动脚本 startup.sh</h3><pre style="overflow-wrap: break-word; background-color: rgb(248, 248, 248); border: 1px solid rgb(204, 204, 204); border-radius: 3px; padding: 2px; margin: 15px 0px; overflow: auto;"><code class="shell hljs bash" style="overflow-wrap: break-word; font-family: Consolas, Monaco, &quot;Andale Mono&quot;, monospace; display: block; overflow-x: auto; padding: 0.5em; background: rgb(35, 36, 31); text-size-adjust: none; color: rgb(248, 248, 242); border: 0px;"><span class="hljs-shebang" style="overflow-wrap: break-word; color: rgb(117, 113, 94);">#!/bin/bash
</span>
PROJECTNAME=sanguo_server_game2

pid=`ps -ef |grep <span class="hljs-variable" style="overflow-wrap: break-word; color: rgb(248, 248, 242);">$PROJECTNAME</span> |grep -v <span class="hljs-string" style="overflow-wrap: break-word; color: rgb(230, 219, 116);">"grep"</span> |awk <span class="hljs-string" style="overflow-wrap: break-word; color: rgb(230, 219, 116);">'{print $2}'</span>`

<span class="hljs-keyword" style="overflow-wrap: break-word; color: rgb(249, 38, 114);">if</span> [ <span class="hljs-variable" style="overflow-wrap: break-word; color: rgb(248, 248, 242);">$pid</span> ]; <span class="hljs-keyword" style="overflow-wrap: break-word; color: rgb(249, 38, 114);">then</span>

​&nbsp; &nbsp; <span class="hljs-built_in" style="overflow-wrap: break-word; color: rgb(230, 219, 116);">echo</span> <span class="hljs-string" style="overflow-wrap: break-word; color: rgb(230, 219, 116);">"<span class="hljs-variable" style="overflow-wrap: break-word; color: rgb(248, 248, 242);">$PROJECTNAME</span>&nbsp;&nbsp;is&nbsp;&nbsp;running&nbsp;&nbsp;and pid=<span class="hljs-variable" style="overflow-wrap: break-word; color: rgb(248, 248, 242);">$pid</span>"</span>

<span class="hljs-keyword" style="overflow-wrap: break-word; color: rgb(249, 38, 114);">else</span>

&nbsp; &nbsp;<span class="hljs-built_in" style="overflow-wrap: break-word; color: rgb(230, 219, 116);">echo</span> <span class="hljs-string" style="overflow-wrap: break-word; color: rgb(230, 219, 116);">"Start success to start <span class="hljs-variable" style="overflow-wrap: break-word; color: rgb(248, 248, 242);">$PROJECTNAME</span> ...."</span>

&nbsp; &nbsp;nohup java -jar jar/sanguo_server_game2.jar&nbsp;&nbsp;&gt;&gt; logs/catalina.out&nbsp;&nbsp;<span class="hljs-number" style="overflow-wrap: break-word; color: rgb(174, 129, 255);">2</span>&gt;&amp;<span class="hljs-number" style="overflow-wrap: break-word; color: rgb(174, 129, 255);">1</span> &amp;

<span class="hljs-keyword" style="overflow-wrap: break-word; color: rgb(249, 38, 114);">fi</span></code></pre></div></td></tr></tbody></table>

#### 停止脚本shutdowm.sh

```
#!/bin/bash 
PROJECTNAME=sanguo_server_game2

pid=`ps -ef |grep $PROJECTNAME |grep -v "grep" |awk '{print $2}' `

if [ $pid ]; then
    echo "$PROJECTNAME is  running  and pid=$pid"

    kill -9 $pid

    if [[ $? -eq 0 ]];then

       echo "sucess to stop $PROJECTNAME "

    else

       echo "fail to stop $PROJECTNAME "

     fi

fi
```

* * *

### 使用方法

替换.sh中的项目名称,注意start.sh有两个需要替换,shutdown中一个

### copy for windows

在从windows中copy到文件后可能出现转义问题等.  
方法:

```
yum -y install dos2unix

dos2unix startup.sh
```

写在末尾
----

在使用此脚本的时候需要注意shutdown.sh,因为它搜索项目是按文件名搜索,  
假设你有A项目叫做 project,B项目叫projectB,当两个项目同时启动时,你在调用A的shutdown.sh时会关闭不掉项目，因为它搜索到的是一个数组,假设你没有启动项目A,调用A的shudown.sh他会关掉B项目

* * *