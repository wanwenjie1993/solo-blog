title: 内网穿透frp linux服务端搭建和windows客户端使用
date: '2019-03-24 23:18:34'
updated: '2019-04-09 13:51:39'
tags: [frp, linux, windows]
permalink: /articles/2019/03/24/1553440714576.html
---
**一、Linux 服务端搭建**
=================

1、下载安装
```
wget --no-check-certificate https://raw.githubusercontent.com/clangcn/onekey-install-shell/master/frps/install-frps.sh -O ./install-frps.sh
```
```
chmod 700 ./install-frps.sh
```
```
./install-frps.sh install
```
2、步骤

Loading network version for frps, please wait...

frps Latest release file frp_0.8.1_linux_amd64.tar.gz#此步骤会自动获取frp最新版本，自动操作，无需理会

Loading You Server IP, please wait...

You Server IP:12.12.12.12#自动获取你服务器的IP地址

Please input your server setting:

Please input frps bind_port [1-65535](Default Server Port: 5443):#输入frp提供服务的端口，用于服务器端和客户端通信

Please input frps dashboard_port [1-65535](Default dashboard_port: 6443):#输入frp的控制台服务端口，用于查看frp工作状态

Please input frps vhost_http_port [1-65535](Default vhost_http_port: 80):#输入frp进行http穿透的http服务端口

Please input frps vhost_https_port [1-65535](Default vhost_https_port: 443):#输入frp进行https穿透的https服务端口

Please input privilege_token (Default: WEWLRgwRjIJVPx2kuqzkGnvuftPLQniq):#输入frp服务器和客户端通信的密码，默认是随机生成的

Please input frps max_pool_count [1-200](Default max_pool_count: 50):#设置每个代理可以创建的连接池上限，默认50

##### Please select log_level #####

1: info    2: warn    3: error    4: debug

Enter your choice (1, 2, 3, 4 or exit. default [1]):#设置日志等级，4个选项，默认是info

Please input frps log_max_days [1-30]

(Default log_max_days: 3 day):#设置日志保留天数，范围是1到30天，默认保留3天。

##### Please select log_file #####

1: enable    2: disable

#####################################################

Enter your choice (1, 2 or exit. default [1]):#设置是否开启日志记录，默认开启，开启后日志等级及保留天数生效，否则等级和保留天数无效

设置完成后检查你的输入，如果没有问题按任意键继续安装

============== Check your input ==============

You Server IP   : 12.12.12.12

Bind port       : 5443

Dashboard port  : 6443

vhost http port : 80

vhost https port: 443

Privilege token : WEWLRgwRjIJVPx2kuqzkGnvuftPLQniq

Max Pool count  : 50

Log level       : info

Log max days    : 3

Log file        : enable

==============================================

安装结束后显示：

Congratulations, frps install completed!

==============================================

You Server IP   : 12.12.12.12

Bind port       : 5443

Dashboard port  : 6443

vhost http port : 80

vhost https port: 443

Privilege token : WEWLRgwRjIJVPx2kuqzkGnvuftPLQniq

Max Pool count  : 50

Log level       : info

Log max days    : 3

Log file        : enable#  将上面信息添加到你的路由器frp穿透插件中吧

==============================================

frps Dashboard: http://ip:6443/#  这个是frp控制台访问地址

==============================================

  

**二、windows客户端使用**
==================

1、下载

http://diannaobos.com/frp/    下载相应版本客户端

2、修改配置文件    frpc.ini

[common]

server_addr = 服务端IP

server_port = 5443

privilege_token = WEWLRgwRjIJVPx2kuqzkGnvuftPLQniq

[ssh]

type = http

local_ip = 127.0.0.1

local_port = 8080

remote_port = 80

custom_domains = 你的域名

**注意：访问服务端的80端口就相当于访问你本地的8080端口**

3、启动

windows cmd里边进入frp客户端相应目录，启动frps.exe即可；成功则看到如下打印：

D:\frp\frp_0.16.1_windows_amd64>frpc.exe

2018/04/25 14:31:00 [I] [proxy_manager.go:298] proxy removed: []

2018/04/25 14:31:00 [I] [proxy_manager.go:308] proxy added: [ssh]

2018/04/25 14:31:00 [I] [proxy_manager.go:331] visitor removed: []

2018/04/25 14:31:00 [I] [proxy_manager.go:340] visitor added: []

2018/04/25 14:31:01 [I] [control.go:240] [f30f90361df8ce96] login to server success, get run id [f30f90361df8ce96], server udp port [0]

2018/04/25 14:31:01 [I] [control.go:165] [f30f90361df8ce96] [ssh] start proxy success

4、访问frp服务端即可看到上述启动的客户端

---

```
==============================================

You Server IP      : 111.231.207.155
Bind port          : 5443
KCP support        : true
vhost http port    : 8888
vhost https port   : 443
Dashboard port     : 6443
token              : QUXJZaBZQiZgwKXL
tcp_mux            : true
Max Pool count     : 50
Log level          : debug
Log max days       : 7
Log file           : enable
==============================================
frps Dashboard     : http://111.231.207.155:6443/
Dashboard user     : admin
Dashboard password : admin?****
==============================================

frps status manage : frps {start|stop|restart|status|config|version}
Example:
  start: frps start
   stop: frps stop
restart: frps restart```