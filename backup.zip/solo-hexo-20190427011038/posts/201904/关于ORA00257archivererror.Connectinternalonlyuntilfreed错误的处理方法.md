title: '关于ORA-00257: archiver error. Connect internal only, until freed 错误的处理方法'
date: '2019-04-01 11:18:18'
updated: '2019-04-01 11:18:18'
tags: [oracle]
permalink: /articles/2019/04/01/1554088698414.html
---
产生原因：出现ORA-00257错误（空间不足错误），通过查找资料，绝大部分说这是由于归档日志太多，占用了全部的硬盘剩余空间导致的，通过简单删除日志或加大存储空间就能够解决。

解决办法：

1，SecureCRT登录服务器，切换用户oracle,连接oracle

```
su - oracle
```

```
sqlplus /nolog
```

```
conn /as sysdba;
```


2，检查flash recovery area的使用情况,可以看见archivelog已经很大了，达到99.94

```
select * from V$FLASH_RECOVERY_AREA_USAGE;
```


3，现在来清理一下archivelog归档日志，生产环境建议备份

查询日志目录位置
```
show parameter recover;
```
5. 修改FLASH_RECOVERY_AREA的空间修改为6GB，修改前确认磁盘有足够空间

```
ALTER SYSTEM SET DB_RECOVERY_FILE_DEST_SIZE=8g;
```

```
select * from V$FLASH_RECOVERY_AREA_USAGE;
```