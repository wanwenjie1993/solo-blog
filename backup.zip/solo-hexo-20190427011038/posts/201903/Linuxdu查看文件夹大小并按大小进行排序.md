title: '[Linux] du-查看文件夹大小-并按大小进行排序'
date: '2019-03-26 10:06:40'
updated: '2019-03-26 14:35:58'
tags: [linux]
permalink: /articles/2019/03/26/1553566000514.html
---
df 命令查看当前磁盘使用情况
`df``-lh `
-s, --summarize display only a total for each argument， -s这个参数的作用就是仅显示总计，即当前文件夹的大小
`du``-sh * `
* 可以将当前目录下所有文件的大小给列出来
`du``-s * |``sort``-nr  `

du -s * | sort -nr | head 选出排在前面的10个，

du -s * | sort -nr | tail 选出排在后面的10个