title: centos7安装jdk环境
date: '2019-03-24 12:36:35'
updated: '2019-03-24 12:38:47'
tags: [java, linux]
permalink: /articles/2019/03/24/1553402195297.html
---
* 下载 jdk-8u131-linux-x64.tar.gz
```
tar -zxvf jdk-8u131-linux-x64.tar.gz
```
```
vim /etc/profile
```
* 在文件尾部添加如下
```
export JAVA_HOME=/root/java/jdk1.8.0_131/
export CLASSPATH=.:$JAVA_HOME/jre/lib/rt.jar:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export PATH=$PATH:$JAVA_HOME/bin
```
* 最后一步就是通过source命令重新加载/etc/profile文件，使得修改后的内容在当前shell窗口有效
```
source /etc/profile
```