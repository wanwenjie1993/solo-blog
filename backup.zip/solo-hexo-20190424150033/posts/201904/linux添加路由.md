title: linux 添加路由
date: '2019-04-22 13:44:51'
updated: '2019-04-22 13:51:37'
tags: [linux]
permalink: /articles/2019/04/22/1555911891640.html
---
`route add 目标IP gw 内网网关 dev eth0`
`route add 111.231.207.155 gw 192.168.2.1 dev eth0`

**添加系统启动路由脚本：**
```
vi /etc/rc.d/rc.local

DNS=`nslookup 127.0.0.1|grep "Server"|awk -F " " '{print $2}'`
GATEWAY=`route -n|tail -1|awk -F " " '{print $2}'`
route add -host $DNS gw $GATEWAY

#CSC_SYNC
route add -host 61.186.249.169 gw $GATEWAY
route add -host 58.17.217.14   gw $GATEWAY
route add -host 183.230.155.74 gw $GATEWAY
#AP360
route add -host 61.186.249.139 gw $GATEWAY
route add -host 58.17.217.17   gw $GATEWAY
route add -host 183.230.155.61 gw $GATEWAY
#company_server
route add -host 61.186.249.141 gw $GATEWAY
route add -host 58.17.217.31   gw $GATEWAY
route add -host 183.230.155.63 gw $GATEWAY
#company_client
route add -host 61.186.249.160 gw $GATEWAY
route add -host 58.17.217.28   gw $GATEWAY
route add -host 183.230.155.70 gw $GATEWAY
#CSC
route add -host 61.186.249.135 gw $GATEWAY
route add -host 58.17.217.13   gw $GATEWAY
route add -host 183.230.155.57 gw $GATEWAY
route add -host 111.231.207.155 gw $GATEWAY
#####
route delete default
```
提示文件权限只读时修改权限
```
chattr -i rc.local
```