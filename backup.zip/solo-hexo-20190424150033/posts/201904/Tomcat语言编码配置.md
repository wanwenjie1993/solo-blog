title: Tomcat语言编码配置
date: '2019-04-01 13:27:08'
updated: '2019-04-01 13:27:08'
tags: [tomcat]
permalink: /articles/2019/04/01/1554096428618.html
---
tomcat服务器server.xml文件设置编码
```
 <Connector connectionTimeout="20000" port="8080" protocol="HTTP/1.1" redirectPort="8443" URIEncoding="UTF-8"/>
```