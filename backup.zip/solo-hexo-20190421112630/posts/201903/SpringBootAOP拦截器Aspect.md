title: SpringBoot AOP 拦截器 Aspect
date: '2019-03-31 22:29:58'
updated: '2019-03-31 22:29:58'
tags: [SpringBoot]
permalink: /articles/2019/03/31/1554042598610.html
---
常用用于实现拦截的有：Filter、HandlerInterceptor、MethodInterceptor

第一种Filter属于Servlet提供的，后两者是Spring提供的，HandlerInterceptor属于Spring MVC项目提供的，用来拦截请求，在MethodInterceptor之前执行。 
实现一个HandlerInterceptor可以实现接口HandlerInterceptor，也可以继承HandlerInterceptorAdapter类，两种方法一样。这个不在本文范围，具体使用之前已经写过SpringBoot的（SpringMVC的使用一样，区别只是配置），可以参考：http://blog.csdn.net/catoop/article/details/50501696?locationNum=2&fps=1

MethodInterceptor是AOP项目中的拦截器，它拦截的目标是方法，即使不是Controller中的方法。 
实现MethodInterceptor拦截器大致也分为两种，一种是实现MethodInterceptor接口，另一种利用Aspect的注解或配置。

关于实现MethodInterceptor接口的这种方法，还需要在配置文件中做配置，在SpringMVC中使用还可以，在SpringBoot中使用起来似乎没有那么方便。

本文主要还是说Aspect注解方式，个人觉得这种方法才比较灵活，与配置与工程整个代码都没有耦合（你添加一个类，做几个注解就可以用了，无需在其他地方再做什么），更易应用。

首先为你的SpringBoot项目添加maven依赖，让其支持aop（其实就是自动引入aop需要的一些jar）

在pom.xml中添加依赖：

    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-aop</artifactId>
    </dependency>
1
2
3
4
然后创建Aspect测试类：

package com.shanhy.sboot.aop;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect // FOR AOP
@Order(-99) // 控制多个Aspect的执行顺序，越小越先执行
@Component
public class TestAspect {

    @Before("@annotation(test)")// 拦截被TestAnnotation注解的方法；如果你需要拦截指定package指定规则名称的方法，可以使用表达式execution(...)，具体百度一下资料一大堆
    public void beforeTest(JoinPoint point, TestAnnotation test) throws Throwable {
        System.out.println("beforeTest:" + test.name());
    }

    @After("@annotation(test)")
    public void afterTest(JoinPoint point, TestAnnotation test) {
        System.out.println("afterTest:" + test.name());
    }

}

这样就完成了，然后创建一个Controller验证一下：

@RestController
@RequestMapping("/test")
public class TestController {

    @TestAnnotation(name="abc")
    @RequestMapping("/show")
    public String show() {
        return "OK";
    }

    @RequestMapping("/show2")
    public String show2() {
        return "OK2";
    }
}

此时我们访问show请求，就会被拦截，控制台会打印输出。如果请求show2则不会被拦截。

注意： 
1、在application.properties中也不需要添加spring.aop.auto=true，因为这个默认就是true，值为true就是启用@EnableAspectJAutoProxy注解了。 
2、你不需要手工添加 @EnableAspectJAutoProxy 注解。 
3、当你需要使用CGLIB来实现AOP的时候，需要配置spring.aop.proxy-target-class=true，这个默认值是false，不然默认使用的是标准Java的实现。

其实aspectj的拦截器会被解析成AOP中的advice，最终被适配成MethodInterceptor，这些都是Spring自动完成的，如果你有兴趣，详细的过程请参考springAOP的实现。

关于集中拦截方法的区别总结： 
HandlerInterceptoer拦截的是请求地址，所以针对请求地址做一些验证、预处理等操作比较合适。当你需要统计请求的响应时间时MethodInterceptor将不太容易做到，因为它可能跨越很多方法或者只涉及到已经定义好的方法中一部分代码。 
MethodInterceptor利用的是AOP的实现机制，在本文中只说明了使用方式，关于原理和机制方面介绍的比较少，因为要说清楚这些需要讲出AOP的相当一部分内容。在对一些普通的方法上的拦截HandlerInterceptoer就无能为力了，这时候只能利用AOP的MethodInterceptor。 
Filter是Servlet规范规定的，不属于spring框架，也是用于请求的拦截。但是它适合更粗粒度的拦截，在请求前后做一些编解码处理、日志记录等。
