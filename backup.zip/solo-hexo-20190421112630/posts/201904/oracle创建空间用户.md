title: oracle创建空间用户
date: '2019-04-09 13:13:38'
updated: '2019-04-09 13:13:38'
tags: [oracle]
permalink: /articles/2019/04/09/1554786818282.html
---
```
sqlplus /nolog
```
```
conn / as sysdba;
```
```
create tablespace wwj_date datafile 'F:\Oracle\Oracle11g\app\oracle\oradata\wwj_date.dbf' size 5000M;
```
```
create temporary tablespace wwj_temp tempfile 'F:\Oracle\Oracle11g\app\oracle\oradata\wwj_temp.dbf' size 32m autoextend on next 32m maxsize 4096m extent management local;
```
```
create user wwj identified by wwj default tablespace wwj_date temporary tablespace wwj_temp;
```
```
grant connect,resource,dba to wwj;
```
---

create tablespace 表间名 datafile '数据文件名' size 表空间大小
--创建临时表空间 
create temporary tablespace test_temp --test_temp表空间名称
tempfile 'F:\Oracle\Oracle11g\app\oracle\oradata\wwj_temp.dbf'--oracle文件路径
size 32m 
autoextend on 
next 32m maxsize 2048m 
extent management local; 

--创建数据表空间 
create tablespace test_data --test_data临时表空间名称
logging 
datafile 'E:\oracle\product\10.2.0\oradata\testserver\test_data01.dbf'--oracle文件路径
size 32m 
autoextend on 
next 32m maxsize 2048m 
extent management local; 

--创建用户并指定表空间 
create user username identified by password --username用户名称
default tablespace test_data --默认用户表空间
temporary tablespace test_temp; --默认临时表空间

--给用户授予权限 
grant connect,resource to username; 
grant dba to username

--删除空的表空间，但是不包含物理文件
drop tablespace tablespace_name;
--删除非空表空间，但是不包含物理文件
drop tablespace tablespace_name including contents;
--删除空表空间，包含物理文件
drop tablespace tablespace_name including datafiles;
--删除非空表空间，包含物理文件
drop tablespace tablespace_name including contents and datafiles;
--如果其他表空间中的表有外键等约束关联到了本表空间中的表的字段，就要加上CASCADE CONSTRAINTS
drop tablespace tablespace_name including contents and datafiles CASCADE CONSTRAINTS;

--说明： 删除了user，只是删除了该user下的schema objects，是不会删除相应的tablespace的。
drop user username cascade