title: VPN搭建和使用
date: '2019-03-26 13:35:23'
updated: '2019-03-26 14:50:03'
tags: [linux, vpn]
permalink: /articles/2019/03/26/1553578523423.html
---
参考：

*   Docker 上的 IPsec VPN 服务器
=======================
https://github.com/hwdsl2/docker-ipsec-vpn-server/blob/master/README-zh.md

* 配置 IPsec/L2TP VPN 客户端
=====================
https://github.com/hwdsl2/setup-ipsec-vpn/blob/master/docs/clients-zh.md


安装 Docker
---------

参考:[Centos7上安装docker](http://111.231.207.155:8888/articles/2019/03/26/1553576290546.html)
 *注：本镜像不支持 Docker for Mac 或者 Windows。*

下载
---------------------------------------------------------------------------------------------------

预构建的可信任镜像可在[Docker Hub registry](https://hub.docker.com/r/hwdsl2/ipsec-vpn-server/)下载：

`docker pull hwdsl2/ipsec-vpn-server `



如何使用本镜像
-----------------------------------------------------------------------------------------------------------------------------------------------------

### [](https://github.com/hwdsl2/docker-ipsec-vpn-server/blob/master/README-zh.md#%E7%8E%AF%E5%A2%83%E5%8F%98%E9%87%8F)环境变量


**重要：**首先，在 Docker 主机上加载 IPsec`af_key`内核模块。该步骤在 Ubuntu 和 Debian 上为可选步骤。

```
sudo modprobe af_key 
```
创建配置文件
```
mkdir wwj
```
```
vi /wwj/vpn.env
```
```
VPN_IPSEC_PSK=wwjvpn
VPN_USER=wanwj1
VPN_PASSWORD=wanwj1
````

使用本镜像创建一个新的 Docker 容器 （将`/wwj/vpn.env`替换为你自己的`env`文件）：

```
docker run \
    --name ipsec-vpn-server \
    --env-file /wwj/vpn.env \
    --restart=always \
    -p 500:500/udp \
    -p 4500:4500/udp \
    -v /lib/modules:/lib/modules:ro \
    -d --privileged \
    hwdsl2/ipsec-vpn-server 
```

### 获取 VPN 登录信息

如果你在上述`docker run`命令中没有指定`env`文件，`VPN_USER`会默认为`vpnuser`，并且`VPN_IPSEC_PSK`和`VPN_PASSWORD`会被自动随机生成。要获取这些登录信息，可以查看容器的日志：

`docker logs ipsec-vpn-server `

在命令输出中查找这些行：

```
Connect to your new VPN with these details:

Server IP: 你的VPN服务器IP
IPsec PSK: 你的IPsec预共享密钥
Username: 你的VPN用户名
Password: 你的VPN密码 
```

（可选步骤）备份自动生成的 VPN 登录信息（如果有）到当前目录：

`docker cp ipsec-vpn-server:/opt/src/vpn-gen.env ./ `

### 查看服务器状态

如需查看你的 IPsec VPN 服务器状态，可以在容器中运行`ipsec status`命令：

`docker exec -it ipsec-vpn-server ipsec status `

或者查看当前已建立的 VPN 连接：

`docker exec -it ipsec-vpn-server ipsec whack --trafficstatus`

-----------------------------------
Windows连接VPN
-------

### [](https://github.com/hwdsl2/setup-ipsec-vpn/blob/master/docs/clients-zh.md#windows-10-and-8x)Windows 10 and 8.x

1.  右键单击系统托盘中的无线/网络图标。
2.  选择**打开网络和共享中心**。或者，如果你使用 Windows 10 版本 1709 或以上，选择**打开"网络和 Internet"设置**，然后在打开的页面中单击**网络和共享中心**。
3.  单击**设置新的连接或网络**。
4.  选择**连接到工作区**，然后单击**下一步**。
5.  单击**使用我的Internet连接 (VPN)**。
6.  在**Internet地址**字段中输入`你的 VPN 服务器 IP`。
7.  在**目标名称**字段中输入任意内容。单击**创建**。
8.  返回**网络和共享中心**。单击左侧的**更改适配器设置**。
9.  右键单击新创建的 VPN 连接，并选择**属性**。
10.  单击**安全**选项卡，从**VPN 类型**下拉菜单中选择 "使用 IPsec 的第 2 层隧道协议 (L2TP/IPSec)"。
11.  单击**允许使用这些协议**。选中 "质询握手身份验证协议 (CHAP)" 和 "Microsoft CHAP 版本 2 (MS-CHAP v2)" 复选框。
12.  单击**高级设置**按钮。
13.  单击**使用预共享密钥作身份验证**并在**密钥**字段中输入`你的 VPN IPsec PSK`。
14.  单击**确定**关闭**高级设置**。
15.  单击**确定**保存 VPN 连接的详细信息。

**注：**在首次连接之前需要**修改一次注册表**。请参见下面的说明。

另外，除了按照以上步骤操作，你也可以运行下面的 Windows PowerShell 命令来创建 VPN 连接。将`你的 VPN 服务器 IP`和`你的 VPN IPsec PSK`换成你自己的值，用单引号括起来：

```shell
# 不保存命令行历史记录
Set-PSReadlineOption –HistorySaveStyle SaveNothing
# 创建 VPN 连接
Add-VpnConnection -Name 'My IPsec VPN' -ServerAddress '你的 VPN 服务器 IP' -L2tpPsk '你的 VPN IPsec PSK' -TunnelType L2tp -EncryptionLevel Required -AuthenticationMethod Chap,MSChapv2 -Force -RememberCredential -PassThru
# 忽略 data encryption 警告（数据在 IPsec 隧道中已被加密）
```

### [](https://github.com/hwdsl2/setup-ipsec-vpn/blob/master/docs/clients-zh.md#windows-7-vista-and-xp)Windows 7, Vista and XP

1.  单击开始菜单，选择控制面板。
2.  进入**网络和Internet**部分。
3.  单击**网络和共享中心**。
4.  单击**设置新的连接或网络**。
5.  选择**连接到工作区**，然后单击**下一步**。
6.  单击**使用我的Internet连接 (VPN)**。
7.  在**Internet地址**字段中输入`你的 VPN 服务器 IP`。
8.  在**目标名称**字段中输入任意内容。
9.  选中**现在不连接；仅进行设置以便稍后连接**复选框。
10.  单击**下一步**。
11.  在**用户名**字段中输入`你的 VPN 用户名`。
12.  在**密码**字段中输入`你的 VPN 密码`。
13.  选中**记住此密码**复选框。
14.  单击**创建**，然后单击**关闭**按钮。
15.  返回**网络和共享中心**。单击左侧的**更改适配器设置**。
16.  右键单击新创建的 VPN 连接，并选择**属性**。
17.  单击**选项**选项卡，取消选中**包括Windows登录域**复选框。
18.  单击**安全**选项卡，从**VPN 类型**下拉菜单中选择 "使用 IPsec 的第 2 层隧道协议 (L2TP/IPSec)"。
19.  单击**允许使用这些协议**。选中 "质询握手身份验证协议 (CHAP)" 和 "Microsoft CHAP 版本 2 (MS-CHAP v2)" 复选框。
20.  单击**高级设置**按钮。
21.  单击**使用预共享密钥作身份验证**并在**密钥**字段中输入`你的 VPN IPsec PSK`。
22.  单击**确定**关闭**高级设置**。
23.  单击**确定**保存 VPN 连接的详细信息。

**注：**在首次连接之前需要[修改一次注册表](https://github.com/hwdsl2/setup-ipsec-vpn/blob/master/docs/clients-zh.md#windows-%E9%94%99%E8%AF%AF-809)，以解决 VPN 服务器 和/或 客户端与 NAT （比如家用路由器）的兼容问题。

要连接到 VPN： 单击系统托盘中的无线/网络图标，选择新的 VPN 连接，然后单击**连接**。如果出现提示，在登录窗口中输入`你的 VPN 用户名`和`密码`，并单击**确定**。最后你可以到[这里](https://www.ipchicken.com/)检测你的 IP 地址，应该显示为`你的 VPN 服务器 IP`。

如果在连接过程中遇到错误，请参见[故障排除](https://github.com/hwdsl2/setup-ipsec-vpn/blob/master/docs/clients-zh.md#%E6%95%85%E9%9A%9C%E6%8E%92%E9%99%A4)。
