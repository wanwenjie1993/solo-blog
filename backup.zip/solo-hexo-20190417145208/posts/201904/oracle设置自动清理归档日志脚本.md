title: oracle设置自动清理归档日志脚本
date: '2019-04-15 11:16:58'
updated: '2019-04-15 11:23:02'
tags: [oracle]
permalink: /articles/2019/04/15/1555298218441.html
---
root用户
```
[root@localhost ~]# mkdir /nstg
[root@localhost ~]# cd /nstg/ 
[root@localhost nstg]# mkdir bin log tmp
[root@localhost nstg]# chown -R oracle:oinstall  /nstg
[root@localhost nstg]# su - oracle
[oracle@localhost ~]$ cd /nstg/bin

 vi del_arch.sh
#!/bin/bash
echo "----------------------------------------`date`---------------------------------------" 
source ~/.bash_profile
rman target / <<EOF
crosscheck archivelog all;
delete noprompt expired archivelog all;
delete noprompt archivelog all completed before 'sysdate-7';
EOF
echo -e "\n" echo "------------------------------------ FINISHED ------------------------------------" 
[oracle@localhost bin]$ crontab -e 
* 1 * * *  nstg/bin/del_arc.sh 
```