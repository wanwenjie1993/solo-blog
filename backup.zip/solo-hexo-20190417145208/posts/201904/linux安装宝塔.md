title: linux安装宝塔
date: '2019-04-10 14:51:16'
updated: '2019-04-10 14:51:16'
tags: [linux]
permalink: /articles/2019/04/10/1554879076893.html
---
```
yum install -y wget && wget -O install.sh http://download.bt.cn/install/install_6.0.sh && bash install.sh
```
* 报错：
![](https://ws1.sinaimg.cn/large/ab71ac88ly1g1xibt5c82j20ra0d8dhr.jpg)

* [CentOS7 无法使用yum命令，无法更新解决方法](http://ezvn.cn/articles/2019/04/10/1554876590985.html)

查看面板地址密码
```
/etc/init.d/bt default
```

