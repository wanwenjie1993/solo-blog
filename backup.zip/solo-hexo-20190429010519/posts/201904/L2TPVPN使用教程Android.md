title: L2TP VPN使用教程-Android
date: '2019-04-09 16:03:04'
updated: '2019-04-09 16:05:20'
tags: [vpn]
permalink: /articles/2019/04/09/1554796984839.html
---
Android
-------

1.  启动**设置**应用程序。
2.  在**无线和网络**部分单击**更多...**。
3.  单击**VPN**。
4.  单击**添加VPN配置文件**或窗口右上角的**+**。
5.  在**名称**字段中输入任意内容。
6.  在**类型**下拉菜单选择**L2TP/IPSec PSK**。
7.  在**服务器地址**字段中输入`你的 VPN 服务器 IP`。
8.  在**IPSec 预共享密钥**字段中输入`你的 VPN IPsec PSK`。
9.  单击**保存**。
10.  单击新的VPN连接。
11.  在**用户名**字段中输入`你的 VPN 用户名`。
12.  在**密码**字段中输入`你的 VPN 密码`。
13.  选中**保存帐户信息**复选框。
14.  单击**连接**。

VPN 连接成功后，会在通知栏显示图标。最后你可以到[这里](https://www.ipchicken.com/)检测你的 IP 地址，应该显示为`你的 VPN 服务器 IP`。

如果在连接过程中遇到错误，请参见[故障排除](https://github.com/hwdsl2/setup-ipsec-vpn/blob/master/docs/clients-zh.md#%E6%95%85%E9%9A%9C%E6%8E%92%E9%99%A4)。