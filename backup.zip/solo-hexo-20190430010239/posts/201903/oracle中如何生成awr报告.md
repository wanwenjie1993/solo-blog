title: oracle中如何生成awr报告
date: '2019-03-25 16:10:01'
updated: '2019-03-25 16:11:37'
tags: [oracle]
permalink: /articles/2019/03/25/1553501400910.html
---
1.  首先打开PL/SQL deleloper ，然后登陆数据库用户。
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=41fef7353a7adab43dd01b43bbd5b36b/58ee3d6d55fbb2fbfaf11c0f434a20a44723dcd1.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=1)
    
2.  PL/SQL deleloper页面我们打开command Windows窗口
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=4902df66dd1373f0f53f6f9f940f4b8b/8601a18b87d6277f066e752524381f30e924fcab.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=2)
    
3.  然后输入@符号按回车键，在数据库安装目录admin下找到awrrpt.sql文件
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=04c8c17cf41986184147ef847aec2e69/503d269759ee3d6de228c3d64f166d224e4adec5.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=3)
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=2ff5bed112178a82ce3c7fa0c602737f/562c11dfa9ec8a13cef413fdfb03918fa1ecc0c5.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=4)
    
4.  然后点击确定，如果我们想要导出的awr格式是html格式，那么我们需要在弹出框输入html
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=25c3cb2c4690f60304b09c470912b370/8b13632762d0f7033eced2c104fa513d2697c5ab.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=5)
    
5.  输入完成后点击确定，如果我们想要导出今天的快照，那么我们在弹出框输入1即可
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=8bc53e672ca446237ecaa562a8237246/c75c10385343fbf254f6e23ebc7eca8064388fd1.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=6)
    
6.  输入完成点击确定，然后输入begin_snap
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=c2495a151330e924cfa49c317c086e66/0df3d7ca7bcb0a46375ecc246763f6246b60afab.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=7)
    
7.  输入完成begin_snap后，我们需要输入end_snap
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=afc478da9c529822053339c3e7cb7b3b/faf2b2119313b07e2367141500d7912396dd8cd1.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=8)
    
8.  然后点击确定按钮，页面会弹出保存路径，此时我们不需要输入任何信息，直接点击确定按钮即可。
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=e0ab2022d5f9d72a1764101de42b282a/77094b36acaf2edd592b0df4811001e9380193d1.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=9)
    
9.  点击确定之后，页面会导出awr报告数据信息到指定的目录
    
    [![oracle数据库AWR报告如何生成](https://imgsa.baidu.com/exp/w=500/sign=aa277bfc6ed9f2d3201124ef99ed8a53/eaf81a4c510fd9f906f91174292dd42a2934a4c5.jpg)](http://jingyan.baidu.com/album/8ebacdf07b190749f65cd50d.html?picindex=10)