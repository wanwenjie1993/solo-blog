title: Tomcat 证书部署
date: '2019-04-17 13:03:22'
updated: '2019-04-17 13:03:22'
tags: [tomcat]
permalink: /articles/2019/04/17/1555477402081.html
---
### Tomcat 证书部署

#### 证书安装

1.  登录 Tomcat 服务器。
2.  将已获取到的`www.domain.com.jks`密钥库存放至 conf 目录下。
3.  编辑同目录下的`server.xml`文件。修改如下内容：
    
    ```
    <Connector port="443" protocol="HTTP/1.1" SSLEnabled="true"
     maxThreads="150" scheme="https" secure="true"
     keystoreFile="conf/www.domain.com.jks"
     keystorePass="changeit"
     clientAuth="false" sslProtocol="TLS" />
    ```
    
    配置文件的主要参数说明如下：
    *   clientAuth：如果设为 true，表示 Tomcat 要求所有的 SSL 客户出示安全证书，对 SSL 客户进行身份验证。
    *   keystoreFile：指定 keystore 文件的存放位置，可以指定绝对路径，也可以指定相对于 <CATALINA_HOME> （Tomcat安装目录）环境变量的相对路径。如果此项没有设定，默认情况下，Tomcat 将从当前操作系统用户的用户目录下读取名为 “.keystore” 的文件。
    *   keystorePass：密钥库密码，指定 keystore 的密码。申请证书时若设置了私钥密码，请填写私钥密码；若申请证书时未设置私钥密码，请填写 Tomcat 文件夹中 keystorePass.txt 文件的密码。
    *   sslProtocol：指定套接字（Socket）使用的加密/解密协议，默认值为 TLS。
4.  重启 Tomcat 服务器，即可使用`https://www.domain.com`进行访问。

#### HTTP 自动跳转 HTTPS 的安全配置

1.  打开 conf 目录下的`web.xml`文件，找到`</welcome-file-list>`标签。
2.  在`</welcome-file-list>`下面换行，并添加以下内容：
    
    ```
    <login-config>
     <!-- Authorization setting for SSL -->
     <auth-method>CLIENT-CERT</auth-method>
     <realm-name>Client Cert Users-only Area</realm-name>
     </login-config>
     <security-constraint>
     <!-- Authorization setting for SSL -->
     <web-resource-collection>
     <web-resource-name>SSL</web-resource-name>
     <url-pattern>/*</url-pattern>
     </web-resource-collection>
     <user-data-constraint>
     <transport-guarantee>CONFIDENTIAL</transport-guarantee>
     </user-data-constraint>
     </security-constraint>
    ```
    
3.  打开同目录下的`server.xml`文件，将 redirectPort 参数修改为 SSL 的 connector 的端口，即443端口。如下所示：
    
    ```
    <Connector port="8080" protocol="HTTP/1.1"
     connectionTimeout="20000"
     redirectPort="443" />
    ```
    
    > 说明：
    > 
    > 此修改可将非 SSL 的 connector 可以跳转到 SSL 的 connector 中。
    
4.  重启 Tomcat 服务器，即可生效。