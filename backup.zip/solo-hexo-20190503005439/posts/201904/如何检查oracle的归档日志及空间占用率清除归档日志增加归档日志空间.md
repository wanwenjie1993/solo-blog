title: 如何检查oracle的归档日志及空间占用率,清除归档日志,增加归档日志空间
date: '2019-04-15 10:06:00'
updated: '2019-04-15 10:47:33'
tags: [oracle]
permalink: /articles/2019/04/15/1555293960068.html
---
问题描述：

所用数据库为 Oracle 10g ，模式为归档模式，oracle 系统默认的归档空间为2G，由于日志过多，空间写满，数据库的redo文件不能归档，而出现oracle数据库挂起的问题。

oem打开oracle 10g 数据库操作界面，会显示如下错误信息：

     “ 由于输出设备已满或不可用, 归档程序无法归档重做日志。”

数据库无法使用

现将解决办法稍作总结：

方法一：增大归档日志空间的大小
```
#可以通过下面的方法来调整系统的回闪恢复区大小
[oracle@localhost ~]$ sqlplus /nolog
SQL*Plus: Release 10.2.0.4.0 - Production on 星期一 4月 15 10:17:42 2019
Copyright (c) 1982, 2007, Oracle.  All Rights Reserved.
#以SYS身份链接到oracle
SQL> conn / as sysdba
Connected.
#首先是关闭数据库
SQL> shutdown immediate;
ORA-01109: database not open
Database dismounted.
ORACLE instance shut down.
#启动数据库到mount状态
SQL> startup mount
ORACLE instance started.

Total System Global Area 1224736768 bytes
Fixed Size                  2083560 bytes
Variable Size             754976024 bytes
Database Buffers          452984832 bytes
Redo Buffers               14692352 bytes
Database mounted.
#查看回闪恢复区的大小和存放目标
SQL> show parameter db_recovery_file_dest

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_recovery_file_dest                string      /u01/app/oracle/flash_recovery
                                                 _area
db_recovery_file_dest_size           big integer 2G
#修改回闪恢复区的大小
SQL> alter system set db_recovery_file_dest_size = 8G;

System altered.
#打开数据库
SQL> alter database open;

Database altered.

SQL> shutdown immediate;
Database closed.
Database dismounted.
ORACLE instance shut down.
SQL> startup
ORACLE instance started.

Total System Global Area 1224736768 bytes
Fixed Size                  2083560 bytes
Variable Size             754976024 bytes
Database Buffers          452984832 bytes
Redo Buffers               14692352 bytes
Database mounted.
Database opened.
SQL> quit
Disconnected from Oracle Database 10g Enterprise Edition Release 10.2.0.4.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options
[oracle@localhost ~]$ sqlplus

SQL*Plus: Release 10.2.0.4.0 - Production on 星期一 4月 15 10:20:32 2019

Copyright (c) 1982, 2007, Oracle.  All Rights Reserved.

Enter user-name: csc
Enter password: 

Connected to:
Oracle Database 10g Enterprise Edition Release 10.2.0.4.0 - 64bit Production
With the Partitioning, OLAP, Data Mining and Real Application Testing options

SQL> show parameter db_recovery_file_dest

NAME                                 TYPE        VALUE
------------------------------------ ----------- ------------------------------
db_recovery_file_dest                string      /u01/app/oracle/flash_recovery
                                                 _area
db_recovery_file_dest_size           big integer 8G
#查看空间使用率
SQL> select * from v$flash_recovery_area_usage;

FILE_TYPE    PERCENT_SPACE_USED PERCENT_SPACE_RECLAIMABLE NUMBER_OF_FILES
------------ ------------------ ------------------------- ---------------
CONTROLFILE                   0                         0               0
ONLINELOG                     0                         0               0
ARCHIVELOG                26.26                         0              54
BACKUPPIECE                   0                         0               0
IMAGECOPY                     0                         0               0
FLASHBACKLOG                  0                         0               0

6 rows selected.
```
问题解决。数据库恢复使用。


方法二 ：进入oracle清空日志信息，把空间释放出来

启动数据库到mount状态：

 >sqlplus “/as sysdba”

>startup mount

新起一个终端，用rman进入把归档日志删除

命令>rman target/  (只安装了一个oracle10g数据库)

命令>crosscheck archivelog all;  （列出归档日志信息）

命令>delete expired archivelog all;  （将上述列出的归档日志删除）

命令>exit;

此时最好将数据库重新备份一下

把数据库的mount状态更改为open状态

>alter database open;

OK.问题解决，数据库可以使用。

误区：

   在系统清空归档目录的日志信息（即物理删除归档日志，或将归档日志转移至别处）不可取，OS虽然删除了，但oracle系统识别不出来已经清空日志，只能进入oracle清空日志信息，把空间释放出来，（方法二）；或者是把归档空间设置更大（方法一）。

   建议将两种方法结合使用，减少工作量，也避免数据库频繁挂起。同时定时进行数据库完全备份或其他重要数据备份

---------------------------------------------------------------------

select * from v$flash_recovery_area_usage; --查看空间占用率

 select * from v$recovery_file_dest;  --查看归档日志的存放地址;

使用rman清空归档日志

     crosscheck archivelog all;  --查看可以所有的归档文件

     delete expired archivelog all; --清空过期的归档文件

 如何确认归档日志是否过期,rman有一个保留策略,可以定义多少天之前的日志算为过期;

        
   CONFIGURE RETENTION POLICY TO RECOVERY WINDOW OF 14 DAYS;

   让恢复窗口成为14天大小。  
  show all --查看所有的rman策略.

select count(*) from v$archived_log where archived='YES' and deleted='NO'; --查看所有归档，未删除的归档日志  

------------------------检查方法-----------

大多数人会去先检查放归档的目录的磁盘空间是否满了，通过该归档目录空余情况来判断归档空间是否满了，但我觉得这个方法不一定代表实际情况，你看到的可能是一个表面现象。

　　默认情况下我们在dbca建库时，会把归档放在$ORACLE_HOME/ flash_recovery_area 下，并且oracle默认给FRA配置的大为2g

　　这里需要足以两个参数：

　　db_recovery_file_dest string /oracle/flash_recovery_area

　　db_recovery_file_dest_size big integer 2G

　　这里总结一句，如果db_recovery_file_dest 下的存放的归档大小达到db_recovery_file_dest_size 即使该目录下仍然有磁盘空间剩余，oracle也不会去写。

　　这里我建议按照如下步骤去确定：归档空间是否满了?

　　1.首先从系统层面确定归档目录存放的磁盘空间情况：

　　[oracle@localhost bdump]$df -h

　　Filesystem Size Used Avail Use% Mounted on

　　/dev/mapper/VolGroup00-LogVol00 26G 12G 14G 46% /

　　/dev/sda2 19G 16G 2.8G 85% /oracle

　　/dev/sda1 99M 24M 71M 25% /boot

　　tmpfs 978M 508M 470M 52% /dev/shm

　　2. 确定归档存放目录，归档存放目录大小

　　SQL>archive log list;

　　Database log mode Archive Mode

　　Automatic archival Enabled

　　Archive destination USE_DB_RECOVERY_FILE_DEST -------这里默认使用的是DB_RECOVERY_FILE_DEST

　　Oldest online log sequence 17

　　Next log sequence to archive 20

　　Current log sequence 20

　　----也可以按照以下方式查询归档放置的地方

　　SQL>show parameter db_

　　NAME TYPE VALUE

　　------------------------------------ ----------- ------------------------------

　　db_keep_cache_size big integer 0

　　db_name string lixora

　　db_recovery_file_dest string /oracle/flash_recovery_area

　　db_recovery_file_dest_size big integer 2G

　　db_recycle_cache_size big integer 0

　　db_unique_name string lixora

　　-----这里可以看到闪回恢复区里的空间使用情况：

　　SQL>select * From v$flash_recovery_area_usage;   ---------这里可以看到闪回恢复区里的空间占有率情况：

　　FILE_TYPE            PERCENT_SPACE_USED     PERCENT_SPACE_RECLAIMABLE       NUMBER_OF_FILES

　　-----文件类型-------  ---百分比空间 ---------------        -----可收回百分比--------------------               ---------文件编号------

　　CONTROLFILE             0                                                    0                                                                 0

　　ONLINELOG               4.88                                                 0                                                                  1

　　ARCHIVELOG            76.05                                                0                                                                 47

　　BACKUPPIECE          3.1                                                  0                                                                   3

　　IMAGECOPY               0                                                    0                                                                   0

　　FLASHBACKLOG       0                                                    0                                                                    0

　　6 rows selected.

　　------注意这一步才是真正查看归档空间的实际使用情况：

　　SQL>select * from v$recovery_file_dest; ------注意这一步才是真正查看归档空间的实际使用情况：

　　NAME SPACE_LIMIT SPACE_USED SPACE_RECLAIMABLE NUMBER_OF_FILES

　　----------- ---------- ----------------- ---- --------------- -------------------

　　/oracle/flash_recovery_area 2147483648 1804771840 0 51

　　但是还是在系统层面去查看磁盘空间。