title: windows java进程后台启动脚本
date: '2019-04-09 13:11:08'
updated: '2019-04-09 13:11:08'
tags: [java, windows]
permalink: /articles/2019/04/09/1554786668810.html
---
```
%1 mshta vbscript:CreateObject("WScript.Shell").Run("%~s0 ::",0,FALSE)(window.close)&&exit
java -jar F:\xxx.jar
```