title: MySQL免安装版，遇到MSVCR120.dll文件丢失错误的解决方案
date: '2019-03-30 18:19:34'
updated: '2019-03-30 18:25:43'
tags: [windows, mysql]
permalink: /articles/2019/03/30/1553941174223.html
---
进行mysql zip版本的安装时，遇到上图的错误，在网上找了相关的文件拷贝到相应目录下，但还是不行。  
后来终于找到解决方法：下载[VC redist packages for x64](https://www.microsoft.com/en-us/download/details.aspx?id=40784)，下载完成，点击运行即可