title: ezvn博客开源
date: '2019-04-18 15:22:43'
updated: '2019-04-18 15:44:09'
tags: [开源代码]
permalink: /ezvn
---
## 本博客源于solo开源博客修改

[github源码下载](https://github.com/wanwenjie1993/ezvn)

[编译好的程序压缩包下载](http://file.ezvn.cn:8443/file/ezvn.zip)

* 开始使用
1. 使用 MySQL手动建库（库名`solo`，字符集使用`utf8mb4`，排序规则`utf8mb4_general_ci`）
2. 修改数据库配置文件和启动端口

![](https://ws1.sinaimg.cn/large/ab71ac88ly1g26t9ocjjzj20qe0eqaaq.jpg)


![](https://ws2.sinaimg.cn/large/ab71ac88ly1g26t9orbrzj20tb0eqjs6.jpg)
 
3.启动tomcat或idea(eclpise) 启动程序入口`Starter`  

*[下载打包好的](http://file.ezvn.cn:8443/file/ezvn.zip)程序解压后放到\apache-tomcat-7.0.53\webapps\ROOT\目录下*
![](https://ws1.sinaimg.cn/large/ab71ac88ly1g26tlm5o71j20k60ba3za.jpg)
*或者idea(eclpise) 启动程序入口*`Starter`  
![](https://ws1.sinaimg.cn/large/ab71ac88ly1g26tcr208uj20z70fz75d.jpg
)

* 预览图
![](https://ws1.sinaimg.cn/large/ab71ac88ly1g26su8i5j9j211p0h4myn.jpg)
---
![](https://ws4.sinaimg.cn/large/ab71ac88ly1g26suafuvuj211g0h2wh0.jpg)
---
![](https://ws4.sinaimg.cn/large/ab71ac88ly1g26su9odxsj211h0hctcx.jpg)
---
![](https://ws2.sinaimg.cn/large/ab71ac88ly1g26suaw2rcj211j0haacg.jpg)
---
![](https://ws2.sinaimg.cn/large/ab71ac88ly1g26suj4od6j211i0h3myp.jpg)
---
![](https://ws4.sinaimg.cn/large/ab71ac88ly1g26suj6wp2j211g0h33z1.jpg)
---
![](https://ws1.sinaimg.cn/large/ab71ac88ly1g26suj1pi3j211i0hejsw.jpg)