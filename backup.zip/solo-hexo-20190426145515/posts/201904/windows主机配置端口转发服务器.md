title: windows主机配置端口转发服务器
date: '2019-04-22 14:26:53'
updated: '2019-04-22 14:26:53'
tags: [linux, frp]
permalink: /articles/2019/04/22/1555914413721.html
---
* 下载[Windows_X64_服务器端](https://file.ezvn.cn:8443/file/frp/windows/frps.exe)
*   创建并修改frps.ini配置文件  
    可参考[配置文件](https://file.ezvn.cn:8443/file/frp/windows/frps.ini)
```
[common]
bind_addr = 0.0.0.0
#监听端口
bind_port = 5443
#WEB端口
dashboard_port = 6443
dashboard_user = admin
dashboard_pwd = admin
vhost_http_port = 8093
vhost_https_port = 8444
log_file = ./frps.log
log_level = info
log_max_days = 3
token = wanwj1
max_pool_count = 50
tcp_mux = true
```
* [服务端后台启动脚本](https://file.ezvn.cn:8443/file/frp/windows/frpsStart.bat)
```
%1 mshta vbscript:CreateObject("WScript.Shell").Run("%~s0 ::",0,FALSE)(window.close)&&exit
C:\xxx\frp\frps.exe -c C:\xxx\frp\frps.ini
```
* 以上步骤完成还需开放配置的端口
* 配合客户端使用[Linux 二级网络端口映射](https://ezvn.cn/articles/2019/04/22/1555913414965.html)
