title: L2TP VPN使用教程-iOS
date: '2019-04-09 16:03:48'
updated: '2019-04-09 16:03:48'
tags: [vpn]
permalink: /articles/2019/04/09/1554797028023.html
---
iOS
---

1.  进入设置 -> 通用 -> VPN。
2.  单击**添加VPN配置...**。
3.  单击**类型**。选择**L2TP**并返回。
4.  在**描述**字段中输入任意内容。
5.  在**服务器**字段中输入`你的 VPN 服务器 IP`。
6.  在**帐户**字段中输入`你的 VPN 用户名`。
7.  在**密码**字段中输入`你的 VPN 密码`。
8.  在**密钥**字段中输入`你的 VPN IPsec PSK`。
9.  启用**发送所有流量**选项。
10.  单击右上角的**完成**。
11.  启用**VPN**连接。

VPN 连接成功后，会在通知栏显示图标。最后你可以到[这里](https://www.ipchicken.com/)检测你的 IP 地址，应该显示为`你的 VPN 服务器 IP`。

如果在连接过程中遇到错误，请参见[故障排除](https://github.com/hwdsl2/setup-ipsec-vpn/blob/master/docs/clients-zh.md#%E6%95%85%E9%9A%9C%E6%8E%92%E9%99%A4)。