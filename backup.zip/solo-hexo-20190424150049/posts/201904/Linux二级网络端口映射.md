title: Linux 二级网络端口映射
date: '2019-04-22 14:10:15'
updated: '2019-04-22 14:27:55'
tags: [linux, frp]
permalink: /articles/2019/04/22/1555913414965.html
---
* 下载[Linux_X64_frpc客户端](https://file.ezvn.cn:8443/file/frp/linux/frpc)
* 创建并修改frpc.ini配置文件
可参考[配置文件](https://file.ezvn.cn:8443/file/frp/linux/frpc.ini)
```
[common]
#服务器ip
server_addr = ezvn.cn 
#服务器端口
server_port = 5443
#认证token
token = wanwj1
log_file = frpc.log 
log_level = info 
log_max_days = 7 
#代理名称
[ssh_5668]
#代理类型
type = tcp
#本地IP
local_ip = 192.168.2.22
#本地端口
local_port = 7022
#转发映射端口
remote_port = 8001
```
* 上传文件到目录`/home/frp/`
* 启动命令
```
nohup /home/frp/frpc -c /home/frp/frpc.ini > /dev/null 2>&1 &
```
* [添加开机启动脚本](https://ezvn.cn/articles/2019/04/22/1555911163939.html)

* 以上步骤完成后可访问 ezvn.cn：8001 连接到内网ssh