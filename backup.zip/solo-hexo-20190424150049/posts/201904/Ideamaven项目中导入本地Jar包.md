title: Idea maven项目中导入本地Jar包
date: '2019-04-09 14:55:32'
updated: '2019-04-09 14:55:32'
tags: [idea]
permalink: /articles/2019/04/09/1554792932000.html
---
**cmd命令行进入到maven安装目录下**
```
mvn install:install-file -Dfile=F:\All-jar\ojdbc14_g.jar -DgroupId=com -DartifactId=ojdbc14_g -Dversion=14 -Dpackaging=jar
```