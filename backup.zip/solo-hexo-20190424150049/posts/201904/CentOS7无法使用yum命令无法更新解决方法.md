title: CentOS7 无法使用yum命令，无法更新解决方法
date: '2019-04-10 14:09:51'
updated: '2019-04-10 14:09:51'
tags: [linux]
permalink: /articles/2019/04/10/1554876590985.html
---
**修改CentOS-Base.repo中的地址**  

若上述方法还是无效可以尝试修改CentOS-Base.repo中的地址

1、进入 "/etc/yum.repos.d" 。

2、编辑 "vi CentOS-Base.repo" 。

3、将所有的 "mirrorlist" 注释掉，将所有的 "baseurl" 取消注释。
![](https://ws4.sinaimg.cn/large/ab71ac88ly1g1xiairqizj20n50bjjt3.jpg)