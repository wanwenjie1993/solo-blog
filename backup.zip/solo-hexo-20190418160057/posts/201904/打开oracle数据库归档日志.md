title: 打开oracle数据库归档日志
date: '2019-04-09 13:15:04'
updated: '2019-04-09 13:15:04'
tags: [oracle]
permalink: /articles/2019/04/09/1554786904167.html
---
```
sqlplus /nolog
```
```
conn/as sysdba; 
```
```
shutdown immediate;           –关闭数据库 
```
```
startup mount;                 – 打开数据库  
```
```
alter database archivelog;   -开启归档日志  noarchivelog;关闭
```
```
alter database open;        –开启数据库 
```
```
archive log list;           – 查看归档日志是否开启
```