title: oracle11g安装教程
date: '2019-04-18 14:37:23'
updated: '2019-04-18 15:03:40'
tags: [oracle]
permalink: /articles/2019/04/18/1555569443614.html
---
又是十月南京阴雨天气 图书馆花了一个多小左右把11g安装折腾好了。其中折腾SQL Developer 花了好长时间，总算搞定了。好了，先总结下安装步骤，希望给后面的童鞋提高安装效率。 相互方便  共同进步！ Oracle两个文件有需要的可以留言give you

一、Oracle [下载](http://www.2cto.com/soft)

注意Oracle分成两个文件，下载完后，将两个文件解压到同一目录下即可。 路径名称中，最好不要出现中文，也不要出现空格等不规则字符。  
 

官方下地址：

http://www.oracle.com/technetwork/database/enterprise-edition/downloads/index.html以下两网址来源此官方下载页网。

win 32位操作系统 下载地址：

http://download.oracle.com/otn/nt/oracle11g/112010/win32_11gR2_database_1of2.zip

http://download.oracle.com/otn/nt/oracle11g/112010/win32_11gR2_database_2of2.zip  
 

win 64位操作系统 下载地址：

http://download.oracle.com/otn/nt/oracle11g/112010/win64_11gR2_database_1of2.zip

http://download.oracle.com/otn/nt/oracle11g/112010/win64_11gR2_database_2of2.zip

二、Oracle安装

1. 解压缩文件，将两个压缩包一起选择， 鼠标右击 ->  解压文件 如图  
 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140444000-1456594352.png)

  
 

2.两者解压到相同的路径中，如图：  
 

![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140455328-634448040.png)

  
 

3. 到相应的解压路径上面，找到可执行安装文件【 setup.exe 】双击安装。如图：  
 

![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140507625-1071165067.png)

  
 

4. 安装第一步：配置安全更新，这步可将自己的电子邮件地址填写进去（也可以不填写，只是收到一些没什么用的邮件而已）。取消下面的“我希望通过My Oracle Support接受安全更新(W)”。 如图：  
 

 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140521875-381654671.png)

  
5. 安全选项，直接选择默认创建和配置一个数据库(安装完数据库管理软件后，系统会自动创建一个数据库实例)。 如图：  
 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140533046-695234472.png)

  
6. 系统类，直接选择默认的桌面类就可以了。(若安装到的电脑是，个人笔记本或个人使用的电脑使用此选项) 如图：  
 

 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140543609-1365052231.png)

  
7. 典型安装。 重要步骤。建议只需要将Oracle基目录更新下，目录路径不要含有中文或其它的特殊字符。全局数据库名可以默认，且口令密码，必须要牢记。密码输入时，有提示警告，不符合Oracel建议时不用管。 (因Oracel建议的密码规则比较麻烦， 必须是大写字母加小写字母加数字，而且必须是8位以上。麻烦，可以输入平常自己习惯的短小密码即可)  如图：  
 

 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140559125-922326088.png)

  
8. 若输入的口令短小简单，安装时会提示如下。直接确认Y继续安装就是了。如图：  
 

 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140613906-867620447.png)

  
9. 先决条件检查。 安装程序会检查软硬件系统是否满足，安装此Oracle版本的最低要求。 直接下一步就OK 了。如图：  
 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140627171-1894249084.png)

  
10. 概要 安装前的一些相关选择配置信息。 可以保存成文件 或 不保存文件直接点完成即可。如图：  
 

 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140638218-1632062320.png)

  
11. 安装产品 自动进行，不用管。如图：  
 

 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140652968-1973865502.png)

  
12. 数据库管理软件文件及dbms文件安装完后，会自动创建安装一个实例数据库默认前面的orcl名称的数据库。如图：  
 

![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140703796-1419965047.png)

  
13. 实例数据库创建完成了，系统 默认是把所有账户都锁定不可用了(除sys和system账户可用外)，建议点右边的口令管理，将常用的scott账户解锁并输入密码。 如图：  
 

 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140716484-12521396.png)

  
14. 解锁scott账户， 去掉前面的绿色小勾，输入密码。同样可以输入平常用的短小的密码，不必非得按oracle建议的8位以上大小写加数字，麻烦。呵呵。如图：  
 

![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140734250-491291498.png)

  
15. 同样，密码不符合规则会提示。不用管它，继续Y即可。如图：  
 

 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140743296-276843682.png)

16. 安装成功，完成即可。 简单吧，呵呵。如图：  
 

 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029140751812-135937968.png)

三、安装后，进入小测试下。

可以通过开始，应用程序中的"Oracle 11g" -> "应用[程序开发](http://www.2cto.com/kf)" -> "Sql Developer 或Sql Plus" 连接。

注意第一次，使用SQL Developer时，会提示指定 java.exe的路径，这里千万别指定自己的java_home了（我就是开始不知道，指定一个JDK6，结束说不兼容。）可以使用Oracel安装路径下面的jdk路径 

D:\Installation\oracle\product\11.2.0\dbhome_1\jdk\jre\bin（我的笔记本）

 具体是：如图：。  
 ![](https://images2015.cnblogs.com/blog/729148/201610/729148-20161029141000828-1132665059.png)

  
当然若不小心，选择错了。选择了java_home中的高级版本，打开SQL Developer报错后不兼容，也有办法解决。可以在

【F:\app\chen\product\11.2.0\dbhome_1\sqldeveloper\sqldeveloper\bin】路径下找到【sqldeveloper.conf】文件后打开

找到SetJavaHome 所匹配的值，删除后面的配置内容。保证时会提示，只读文件不可覆盖保存。此时可以另存为到桌面上，然后再回到bin目录中删除掉此文件，再把桌面上的文件复制过去，再打开时，重新选择java.exe。此时选择对就好了。

--------------------------------------------------------------------------------------------------------------------------------------

安装64位版Oracle11gR2后发现启动SQL Developer时弹出配置java.exe的路径，找到Oracle自带java.exe后产生的路径“C:\app\用户名\product\11.2.0\dbhome_1\jdk”却弹出错误信息：

－－－－－－－－－－－－－－－－－－－－－－－－－－  
Unable to find a java Virtual Machine  
to point to a location of a java virtual machine,please refer to the oracle9i Jdeveloper Install guide(jdev\install.html)  
－－－－－－－－－－－－－－－－－－－－－－－－－－

　　由于没有重新配置的机会，只好到安装目录“C:\app\用户名\product\11.2.0\dbhome_1\sqldeveloper0\sqldeveloper\bin”中找到配置文件sqldeveloper.conf，修改其中“SetJavaHome”项为“SetJavaHome C:\Program Files\Java\jdk1.6.0_21”，这是另一个单独安装的JDK，结果还是一样。

　　于是，又配置成MyEclipse8.5所带的JDK路径“SetJavaHome C:\Users\用户名\AppData\Local\Genuitec\Common\binary\com.sun.java.jdk.win32.x86_1.6.0.013”，一切正常，正纳闷时，到网络上搜了一下，找到“http://forums.oracle.com/forums/thread.jspa?messageID=4449178”后终于受到了启发，弄明白是怎么回事。

　　原来Oracle在制造64位版的时候没注意Oracle11gR2所带的SQL Developer是1.5.5.59.69版，不支持64位版的JDK，恰好64位Oracle带的JDK和“C:\Program Files”中的JDK都是64位的。如果你单独安装的JDK中“C:\Program Files (x86)”中则说明是32位版的，是可以用的。为什么MyEclipse所带的JDK可用呢，因为MyEcipse8.5没有64位版（包括最新的8.6也一样），所以其中带的JDK当然是32位版的了。明白了吗？

　　再来看看解决方案：

　　既然你已经决定了要用64位版的Oracle11gR2：

（1）单独安装一个32位版的JDK就可以直接配置了；

（2）升级SQL Developer到2.1，把原来“C:\app\用户名\product\11.2.0\dbhome_1”下的的删除，下载（[http://download.oracle.com/otn/java/sqldeveloper/sqldeveloper64-2.1.1.64.45-no-jre.zip](http://download.oracle.com/otn/java/sqldeveloper/sqldeveloper64-2.1.1.64.45-no-jre.zip)）回来直接解压得到一个sqldeveloper文件夹放到同一位置即可。这时即可以配置“C:\Program Files”下的JDK，而Oracle自带的JDK，还是不能用的，因为这个2.1版的SQL Developer需要的JDK是1.6.0_04以上，而Oracle11gR2自带的JDK版本只有1.5.0_17。

　　还没完哟，还有个小小的问题没有解决，“开始”菜单中的那个“SQL Developer”是指向“C:\app\用户名\product\11.2.0\dbhome_1\sqldeveloper\sqldeveloper\bin\sqldeveloper.bat”的，这个无法启动，也许你的机器可以启动，网络上有人说过这个问题，打开这个文件一看，内容是：

java -Xmx640M -Xms128M -Xverify:none -Doracle.ide.util.AddinPolicyUtils.OVERRIDE_FLAG=true -Dsun.java2d.ddoffscreen=false -Dwindows.shell.font.languages= -XX:MaxPermSize=128M -Dide.AssertTracingDisabled=true -Doracle.ide.util.AddinPolicyUtils.OVERRIDE_FLAG=true -Djava.util.logging.config.file=logging.conf -Dsqldev.debug=false -Dide.conf="./sqldeveloper.conf" -Dide.startingcwd="." -classpath ../../ide/lib/ide-boot.jar oracle.ide.boot.Launcher

　　解决办法是：把前面的“-Xmx640M”修改为“-Xmx512M”即可。但运行这个命令，单击那个允许运行程序的“是”后，没有任何反应，但直接在资源管理器中运行这个BAT文件会弹出一上类似DOS的窗口有很多信息显示后又弹出一个窗口，这个就是了。这样运行感觉不太好，所以继续改造：

　　在“开始”菜单中的“SQL Developer”上右击选属性，把目标中的“C:\app\用户名\product\11.2.0\dbhome_1\sqldeveloper\sqldeveloper\bin\sqldeveloper.bat”修改为“C:\app\用户名\product\11.2.0\dbhome_1\sqldeveloper\sqldeveloper\bin\sqldeveloperW.exe”即可。

　　至于默认运行“sqldeveloper.bat”，应该有其道理，知道原理者可以补充一下。