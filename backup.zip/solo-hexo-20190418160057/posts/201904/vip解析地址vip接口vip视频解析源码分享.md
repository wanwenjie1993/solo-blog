title: vip解析地址,vip接口,vip视频解析源码分享
date: '2019-04-18 14:10:25'
updated: '2019-04-18 14:55:25'
tags: [vip解析]
permalink: /vip
---
* [vip解析地址](http://ezvn.cn:8888/)

* [vip视频解析源码分享](https://file.ezvn.cn:8443/file/vip.zip)

Vip视频解析
============================

Vip视频解析是一款开源视频播放框架。
基于[北漂鱼开源](https://github.com/Beipy/VipVideoResolution)上修改的
具有切换接口、自适应手机端、和后台更改接口、以及聊天插件同步等功能。

#### 程序相关配置

安装后为了安全，请自行更改后台目录位置文件夹名称！

*   [在线演示](http://ezvn.cn:8888/)
*   默认后台管理页面`/admin`；
*   默认后台账号：admin
*   默认后台密码：admin

#### 运行环境

PHP 5.4+ （使用前请检查服务器运行环境是否低于5.4，否则会出现后台保存自动转义添加斜杠问题。）