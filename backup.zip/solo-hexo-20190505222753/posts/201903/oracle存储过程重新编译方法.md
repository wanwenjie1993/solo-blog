title: oracle 存储过程重新编译方法
date: '2019-03-27 10:30:57'
updated: '2019-03-27 10:30:57'
tags: [oracle]
permalink: /articles/2019/03/27/1553653857401.html
---
第一种  如果你使用 PL/SQL Developer工具   
        左侧工具栏中选择“存储过程”-》选择已经失效的procedure-》右键-》选择重新编译 即可完成  
  
  
第二种  命令行版  
1.查找到无效对象  
select 'Alter '||object_type||' '||object_name||' compile;' from user_objects where status = 'INVALID';  
  
2.重新编译存储过程 pro_backup_call 执行下面脚本即可  
alter procedure pro_backup_call compile;