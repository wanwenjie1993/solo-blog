title: 'winRAR终极去广告【最终版】适用winrar所有版本 '
date: '2019-03-26 22:26:41'
updated: '2019-03-26 22:40:48'
tags: [windows]
permalink: /articles/2019/03/26/1553610400920.html
---
* 到WinRAR官网[下载](https://www.rarlab.com/rar/winrar-x64-570sc.exe)自己需要的版本，安装即可
* 将下面注册的文字保存为 rarreg.key 注册并复制和替换到WinRAR的安装目录下
```
RAR registration data 
Federal Agency for Education 
1000000 PC usage license 
UID=b621cca9a84bc5deffbf 
6412612250ffbf533df6db2dfe8ccc3aae5362c06d54762105357d 
5e3b1489e751c76bf6e0640001014be50a52303fed29664b074145 
7e567d04159ad8defc3fb6edf32831fd1966f72c21c0c53c02fbbb 
2f91cfca671d9c482b11b8ac3281cb21378e85606494da349941fa 
e9ee328f12dc73e90b6356b921fbfb8522d6562a6a4b97e8ef6c9f 
fb866be1e3826b5aa126a4d2bfe9336ad63003fc0e71c307fc2c60 
64416495d4c55a0cc82d402110498da970812063934815d81470829275
```
* 下载resource hacker软件([EXE install](http://www.angusj.com/resourcehacker/reshacker_setup.exe)(2.9MB))，进行文件的编译与反编译,
下载安装完之后先关闭winrar
* 打开resource hacker，点左上角的“File-Open”，选择winrar安装目录下的winrar.exe, 双击打开后在左边找到“String Table“，找到80：选项右边的1277整行删掉
  
* 保存之后，再随便双击打开一个压缩包，就不再自动弹出广告了  
  
  
* 关于升级：每次可升级，升级之后再重复第四步即可