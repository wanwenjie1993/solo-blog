title: Linux（Centos7）下搭建SVN服务器
date: '2019-03-28 14:05:25'
updated: '2019-03-28 16:22:00'
tags: [linux, svn]
permalink: /articles/2019/03/28/1553753125671.html
---
**系统环境：centos7.2**

**第一步：通过yum命令安装svnserve，命令如下：**

`yum -y install subversion`

此命令会全自动安装svn服务器相关服务和依赖，安装完成会自动停止命令运行

若需查看svn安装位置，可以用以下命令：

`rpm -ql subversion`

**第二步：创建版本库目录（此仅为目录，为后面创建版本库提供存放位置）**

选择在var路径下创建版本库，当前处于根目录下，一次性创建如下：

`mkdir /var/svnrepos`

**第三步：创建svn版本库**

在第二步建立的路径基础上，创建版本库，命令如下：

`svnadmin create /var/svnrepos/xxxx `

 （xxxx为你预期的版本库名称，可自定义）

创建成功后，进入xxxx目录下

`cd /var/svnrepos/xxxx`

进入目录，可以看见如下文件信息：


```
total 24 drwxr-xr-x 2 root root 4096 May  2 13:48 conf
drwxr-sr-x 6 root root 4096 May  2 13:48 db -r--r--r-- 1 root root    2 May  2 13:48 format
drwxr-xr-x 2 root root 4096 May  2 13:48 hooks
drwxr-xr-x 2 root root 4096 May  2 13:48 locks -rw-r--r-- 1 root root  229 May  2 13:48 README.txt
```


**第四步：配置修改**

进入已经创建好的版本库目录下，也就是前文说创建的xxxx，进入conf

`cd /var/svnrepos/xxxx/conf`

conf目录下，一共存放三份重要的配置文件，如下：

```
total 12
-rw-r--r-- 1 root root 1080 May  2 13:48 authz -rw-r--r-- 1 root root  309 May  2 13:48 passwd
-rw-r--r-- 1 root root 3090 May  2 13:48 svnserve.conf
```

authz：负责账号权限的管理，控制账号是否读写权限

passwd：负责账号和密码的用户名单管理

svnserve.conf：svn服务器配置文件

1.编辑 authz 文件（注意：[/]也是必须的）
添加
```
[/]
luo = rw
```
[/]：表示根目录，即 /var/svnrepos

luo = rw：表示用户luo对根目录具有读写权限。

2.编辑 passwd 文件


如上所示，用户名为：luo，认证密码为：luo123456

3.编辑 svnserve.conf 文件（注意：配置的前面不能有空格，一定要顶格写）
[general]添加
```
anon-access = none
auth-access = write
password-db = passswd
authz-db = authz
realm = /var/svnrepos
```
anon-access = none：表示禁止匿名用户访问。

auth-access = write：表示授权用户拥有读写权限。

password-db = passswd：指定用户名口令文件，即 passwd 文件。

authz-db = authz：指定权限配置文件，即 authz 文件。

realm = /var/svnrepos：指定认证域，即 /var/svnrepos 目录。

**第五步：防火墙开启（端口3690）**

**六：启动svn服务器**

`svnserve -d -r /var/svnrepos`

启动成功后，可用ps -aux查看服务启动是否成功

`ps -ef | grep 'svnserve'`

**七：客户端访问svn服务器**

在windows客户端，输入地址：svn://ip地址:3690/xxxx   （iP地址为你linux的ip，xxxx为前文创建的版本库名称,3690为svn默认端口）

弹出输入用户名和密码，输入即可访问

或者在linux服务器输入命令测试：

`svn co svn://ip地址:3690/xxxx`


遇到的问题小结：

问题1：执行svn命令：svn co svn://ip地址:3690/xxxx报错如下

![](https://images2018.cnblogs.com/blog/867078/201805/867078-20180502150422317-1135779475.png)

这是因为修改svnserve.conf时，打开注释时，配置的前面有空格，应该顶格写。修改后即可

问题2：输入账号密码后，提示 svn: Authorization failed解决办法

把authz 文件 [/] 改为 [\] 试试