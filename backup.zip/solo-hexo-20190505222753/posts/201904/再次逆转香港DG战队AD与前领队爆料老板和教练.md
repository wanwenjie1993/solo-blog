title: 再次逆转,香港DG战队AD与前领队爆料老板和教练
date: '2019-04-25 21:41:14'
updated: '2019-04-25 21:41:14'
tags: [英雄联盟]
permalink: /articles/2019/04/25/1556199674302.html
---
今天凌晨，DG战队宣布打假赛战队AD的污蔑举报，但随后，DG战队AD也发表了微博，否认了该公告中所谓的行为，并表示已记录的证据已被移交。

以下是微博的原文：

![null](https://pic.rmb.bdstatic.com/b9bcd1dc4075cf57237110c881f893c3.png@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_21,x_14,y_14)

微博爆料

* * *

![null](https://pic.rmb.bdstatic.com/b2a270ed24dd8d54129bee651fa72d96.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_36,x_23,y_23)

微博爆料

![null](https://pic.rmb.bdstatic.com/7c21eeecb9b58f36103680deae0d7923.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_36,x_23,y_23)

微博爆料

![null](https://pic.rmb.bdstatic.com/c574ba86e44fe99a9a07e32c01ffbb74.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_36,x_23,y_23)

微博爆料

![null](https://pic.rmb.bdstatic.com/c60079ed529d1bad5c936ee4fcf50459.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_36,x_23,y_23)

微博爆料

![null](https://pic.rmb.bdstatic.com/bfb82f209a28b3edc17a07cb1e4d0184.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_36,x_23,y_23)

微博爆料

![null](https://pic.rmb.bdstatic.com/7cdab7c9ea89e6b7f9a3f4677b6fde6d.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_36,x_23,y_23)

微博爆料

评论截图

![null](https://pic.rmb.bdstatic.com/66ae2562bc17e24a44621489ec462e7d.png@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_17,x_11,y_11)

评论截图

![null](https://pic.rmb.bdstatic.com/61eca55a02455c4cb4d3cf6302e78f3a.png@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_17,x_11,y_11)

评论截图

网友扒出的雅虎的采访。 关键结论是，AD拒绝打假赛，并积极通知队友并一起收集证据。

![null](https://pic.rmb.bdstatic.com/304279d813270825b82a195ee3c338d0.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_28,x_18,y_18)

雅虎采访

在那之后，DG战队上单黄金隆发表Facebook，讲述了和AHQ比赛中教练与AD之间的争吵过程。 AD质疑教练的BP，教练回复：“回了中国要弄死AD”

回基黄金隆想缓和双方的关系单交了却说“回大陆武汉挑手筋的人已经找好了。”

![null](https://pic.rmb.bdstatic.com/95ddfa26fa87ca6210efe0e82703589c.jpeg@c_1,w_440,h_613,x_0,y_0)

黄金隆Facebook

这已经不光是假赛和外围了，如果这名上单选手说的属实，那么DG教练这么做就已经是黑恶势力分子了，这段时间全国严打扫黑，不知道这名教练回大陆后会不会进去。

黄金隆还透露为什么要帮助AD，因为AD发现了战队老板买了外围并搜集了证据。之后当面询问教练，教练给的回答依旧是有做这种事情死全家。

![null](https://pic.rmb.bdstatic.com/994eef3d87ec21e8c2149301ca85208c.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_20,x_13,y_13)

![null](https://pic.rmb.bdstatic.com/3cdb4febdef2ed8ae71fb4d5b6f5a3c9.png@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_16,x_10,y_10)

黄金隆微博

AD选手微博发出了自己保留的证据

![null](https://pic.rmb.bdstatic.com/b2a270ed24dd8d54129bee651fa72d96.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_36,x_23,y_23)

微博证据

![null](https://pic.rmb.bdstatic.com/7c21eeecb9b58f36103680deae0d7923.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_36,x_23,y_23)

微博证据

接着DG前领队也在脸书上爆料老板压榨员工

![null](https://pic.rmb.bdstatic.com/5a33c1d492f4f2cbbb7996f0a7158186.jpeg@wm_2,t_55m+5a625Y+3L2V6dm4=,fc_ffffff,ff_U2ltSGVp,sz_28,x_18,y_18)

DG前领队爆料

这篇脸书中爆料了DG的老板在大陆其实有一个富婆女友，但是这名DG前领队也讲过这个DG的老板曾经让她当在台湾的the other woman。

最近几年，LMS在国际舞台上的表现令人失望。 关于DG战队，我希望LMS能够真正给予公平公正的待遇。这也对LMS赛区的其他战队警示。它也可能有助于改善LMS赛区在国际舞台上的表现。

这个瓜大家怎么看？