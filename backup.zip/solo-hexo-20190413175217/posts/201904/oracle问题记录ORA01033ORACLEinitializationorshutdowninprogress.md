title: 'oracle问题记录 ORA-01033: ORACLE initialization or shutdown in progress'
date: '2019-04-10 11:02:54'
updated: '2019-04-10 11:02:54'
tags: [oracle]
permalink: /articles/2019/04/10/1554865374383.html
---
登录数据库报错
**ORA-01033: ORACLE initialization or shutdown in progress**
```
SQL>shutdown immediate;

SQL> conn / as sysdba
Connected.
SQL> shutdown immediate;
ORA-01109: database not open

Database dismounted.
ORACLE instance shut down.
SQL> SP2-0223: No lines in SQL buffer.
SQL> startup;
ORACLE instance started.

Total System Global Area 1224736768 bytes
Fixed Size                  2083560 bytes
Variable Size             754976024 bytes
Database Buffers          452984832 bytes
Redo Buffers               14692352 bytes
Database mounted.
ORA-16038: log 3 sequence# 399 cannot be archived
ORA-19809: limit exceeded for recovery files
ORA-00312: online log 3 thread 1: '/u01/app/oracle/oradata/orcl/redo03.log'
#从报错信息上可以看出来是归档的日志出错，查看日志的信息
SQL> select group#,sequence# from v$log;

    GROUP#  SEQUENCE#

---------- ----------

         1        400

         3        399

         2        401
#清除出错的日志文件：
SQL> alter database clear unarchived logfile group 3;

Database altered.

SQL>  alter database open;

Database altered.
#重新启用归档：
SQL> alter system archive log start;

System altered.
```
然后关闭重启