title: 动态创建javascript方式
date: '2019-03-24 12:33:19'
updated: '2019-03-24 12:34:45'
tags: [javascript]
permalink: /articles/2019/03/24/1553401999674.html
---
```
var script=document.createElement("script");
script.setAttribute("type", "text/javascript");
script.setAttribute("src", "xxx.js");
var heads = document.getElementsByTagName("head");
if(heads.length)
	heads[0].appendChild(script);
else
	document.documentElement.appendChild(script);
```
