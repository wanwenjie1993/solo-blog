title: '''telnet'' 不是内部或外部命令，也不是可运行的程序 或批处理文件。'
date: '2019-04-09 14:08:28'
updated: '2019-04-09 14:08:28'
tags: [windows]
permalink: /articles/2019/04/09/1554790108080.html
---
* 打开控制面板>程序>打开或关闭windows功能
* 勾选telnet服务器 和  telnet客户端   点击确定
