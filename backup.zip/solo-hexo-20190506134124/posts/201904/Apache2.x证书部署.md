title: Apache 2.x 证书部署
date: '2019-04-17 13:06:35'
updated: '2019-04-17 13:06:35'
tags: [apache]
permalink: /articles/2019/04/17/1555477595007.html
---
### Apache 2.x 证书部署

> 说明：
> 
> 以下操作步骤以 CentOS 7 为例，根据操作系统的版本不同，详细操作步骤略有区别。

1.  使用 “WinSCP” 工具，登录 Apache 服务器。
2.  将已获取到的`1_root_bundle.crt`证书文件、`2_www.domain.com.crt`证书文件以及`3_www.domain.com.key`私钥文件拷贝到 Apache 服务器的`/etc/httpd/ssl`目录下。
    
    > 说明：
    > 
    > 若无`/etc/httpd/ssl`目录，可新建。
    
3.  关闭 WinSCP 界面。
4.  使用 “PuTTY” 工具，登录 Apache 服务器。
5.  找到`LoadModule ssl_module modules/mod_ssl.so`（用于加载 SSL 模块）和`Include conf.modules.d/*.conf`（用于加载配置 SSL 的配置目录）配置语句，并检验是否被注释。
    
    > 说明：
    > 
    > 由于操作系统的版本不同，目录结构也不同，请根据实际操作系统版本进行查找。`LoadModule ssl_module modules/mod_ssl.so`和`Include conf.modules.d/*.conf`配置语句可能配置在以下配置文件中：
    > 
    > *   `conf.modules.d`目录下的 00-ssl.conf 配置文件。
    > *   httpd.conf 配置文件。
    > *   http-ssl.conf 配置文件。
    > 
    > 若以上配置文件中均未找到`LoadModule ssl_module modules/mod_ssl.so`和`Include conf.modules.d/*.conf`配置语句，请确认是否已经安装 mod_ssl.so 模块。若未安装 mod_ssl.so 模块，您可通过执行`yum install mod_ssl`命令进行安装。
    
    *   是，请去掉首行的注释符号（`#`），并保存配置文件。
    *   否，请执行下一步。
6.  编辑`/etc/httpd/conf.d`目录下的 ssl.conf 配置文件。修改如下内容：
    
    ```
    <VirtualHost 0.0.0.0:443>
         DocumentRoot "/var/www/html"
         ServerName www.domain.com
         SSLEngine on
         SSLCertificateFile /etc/httpd/ssl/2_www.domain.com_cert.crt
         SSLCertificateKeyFile /etc/httpd/ssl/3_www.domain.com.key
         SSLCertificateChainFile /etc/httpd/ssl/1_root_bundle.crt
    </VirtualHost>
    ```
    
    配置文件的主要参数说明如下：
    *   SSLEngine on： 启用 SSL 功能
    *   SSLCertificateFile：证书文件的路径
    *   SSLCertificateKeyFile：私钥文件的路径
    *   SSLCertificateChainFile：证书链文件的路径
7.  重新启动 Apache 服务器，即可使用`https://www.domain.com`进行访问。