title: Spring-Boot中Spring Session介绍
date: '2019-03-31 22:22:49'
updated: '2019-03-31 22:22:49'
tags: [SpringBoot]
permalink: /articles/2019/03/31/1554042169782.html
---
在单应用中我们的session来保存用户信息，通常会保存在服务器中（如tomcat），但是我们把应用搭建成分布式的集群，然后利用LVS或Nginx做负载均衡，那么来自同一用户的Http请求将有可能被分发到两个不同的应用中。

   那么如何解决在分布式中的session共享问题。可行的方案有memcached实现session共享，也可以用redis实现。今天主要介绍Spring Session.

    Spring Session提供了一个API和实现来管理用户的会话信息，同时也使得支持集群会话而不被绑定到应用程序容器特定的解决方案而变得微不足道。

     实际上，我们不使用Tomcat的HttpSession，而是将session Id值持久化到Redis中。Spring Session将使用由Redis支持的实现替换HttpSession。

   基于Spring Boot的Spring Session介绍。

 

    （1）pom.xml配置
```
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
 </dependency>
<dependency>
     <groupId>org.springframework.session</groupId>
     <artifactId>spring-session-data-redis</artifactId>
</dependency>
```
在添加所需的依赖项之后，可以创建Spring Boot配置。感谢自动配置支持，在Redis的支持下设置Spring Session就像在您的应用程序中添加一个配置属性一样简单。

（2）application.properties配置

#session存储类型
`spring.session.store-type=redis`
#设置session超时时间
```
server.session.timeout=2000
spring.redis.host=127.0.0.1
spring.redis.port=6379
```
（3）controller中测试
```
@RequestMapping(value = "/index", method = RequestMethod.POST)
@ResponseBody
public PageResultBean<User> index(UserQuery query, HttpServletRequest request) {
   HttpSession session = request.getSession();
    if (session.getAttribute("user") == null) {
      session.setAttribute("user", "zhangsan");
      System.out.println("不存在session");
    } else {
     System.out.println("存在session");
   }
  List<User> list = userService.queryListByPage(query);
  int queryCount = userService.queryCount(query);
  PageResultBean<User> pageResultBean = new PageResultBean<User>();
  pageResultBean.setData(list);
  pageResultBean.setPageNumber(query.getPageNumber());
  pageResultBean.setPageSize(query.getPageSize());
  pageResultBean.setTotalCount(queryCount);
  return pageResultBean;
}
```
对于第一次请求会打印，“不存在session”,这时候就会创建session，并保存到Redis中，同时也会返回给浏览器。
```
 "spring:session:expirations:1521635340000" set类型
 "spring:session:sessions:7e995929-f063-4779-a382-e831bdb88386" 是hash类型
 "spring:session:sessions:expires:7e995929-f063-4779-a382-e831bdb88386"  string类型 
```
通过 hkeys  spring:session:sessions:7e995929-f063-4779-a382-e831bdb88386  ,查询所有的fields
```
maxInactiveInterval   session活跃时间（多少秒后过期） ，默认为180s 30min 
lastAccessedTime  最后一次访问会话的时间 距离1/1/1970 的毫秒
creationTime  session创建时间距离1/1/1970 的毫秒
sessionAttr:user  为session中的一个属性，一般是在程序中自定义的
```