title: L2TP VPN使用教程-Windows 10 and 8.x
date: '2019-04-09 16:00:45'
updated: '2019-04-09 16:12:59'
tags: [vpn]
permalink: /articles/2019/04/09/1554796845360.html
---
### Windows 10 and 8.x
1.  右键单击系统托盘中的无线/网络图标。
2.  选择**打开网络和共享中心**。或者，如果你使用 Windows 10 版本 1709 或以上，选择**打开"网络和 Internet"设置**，然后在打开的页面中单击**网络和共享中心**。
3.  单击**设置新的连接或网络**。
4.  选择**连接到工作区**，然后单击**下一步**。
5.  单击**使用我的Internet连接 (VPN)**。
6.  在**Internet地址**字段中输入`你的 VPN 服务器 IP`。
7.  在**目标名称**字段中输入任意内容。单击**创建**。
8.  返回**网络和共享中心**。单击左侧的**更改适配器设置**。
9.  右键单击新创建的 VPN 连接，并选择**属性**。
10.  单击**安全**选项卡，从**VPN 类型**下拉菜单中选择 "使用 IPsec 的第 2 层隧道协议 (L2TP/IPSec)"。
11.  单击**允许使用这些协议**。选中 "质询握手身份验证协议 (CHAP)" 和 "Microsoft CHAP 版本 2 (MS-CHAP v2)" 复选框。
12.  单击**高级设置**按钮。
13.  单击**使用预共享密钥作身份验证**并在**密钥**字段中输入`你的 VPN IPsec PSK`。
14.  单击**确定**关闭**高级设置**。
15.  单击**确定**保存 VPN 连接的详细信息。

**注：**在首次连接之前需要**[修改一次注册表]([http://ezvn.cn/articles/2019/04/09/1554797384649.html](http://ezvn.cn/articles/2019/04/09/1554797384649.html))**。

另外，除了按照以上步骤操作，你也可以运行下面的 Windows PowerShell 命令来创建 VPN 连接。将`你的 VPN 服务器 IP`和`你的 VPN IPsec PSK`换成你自己的值，用单引号括起来：

```shell
# 不保存命令行历史记录
Set-PSReadlineOption –HistorySaveStyle SaveNothing
# 创建 VPN 连接
Add-VpnConnection -Name 'My IPsec VPN' -ServerAddress '你的 VPN 服务器 IP' -L2tpPsk '你的 VPN IPsec PSK' -TunnelType L2tp -EncryptionLevel Required -AuthenticationMethod Chap,MSChapv2 -Force -RememberCredential -PassThru
# 忽略 data encryption 警告（数据在 IPsec 隧道中已被加密）
```