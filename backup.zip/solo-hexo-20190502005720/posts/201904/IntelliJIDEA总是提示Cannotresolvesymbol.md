title: IntelliJ IDEA总是提示Cannot resolve symbol
date: '2019-04-02 12:24:56'
updated: '2019-04-03 13:40:41'
tags: [idea]
permalink: /articles/2019/04/02/1554179096085.html
---
**_点击File | Invalidate Caches，清理了缓存重启IDEA就可以了_**
* 移除掉无用的模块